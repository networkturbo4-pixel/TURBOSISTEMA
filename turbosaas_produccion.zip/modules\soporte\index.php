<?php
require_once '../../config/db.php';
requireLogin();
requirePermission($pdo, 'soporte');

include '../../includes/header.php';
include '../../includes/sidebar.php';

// Obtener categorías y prioridades y técnicos para los select
$categorias = $pdo->query("SELECT * FROM ticket_categories ORDER BY name")->fetchAll();
$prioridades = $pdo->query("SELECT * FROM ticket_priorities ORDER BY level DESC, name ASC")->fetchAll();
$tecnicos = $pdo->query("SELECT id, name FROM users WHERE role != 'user' ORDER BY name")->fetchAll(); // Asumiendo 'user' es cliente
$clientes = $pdo->query("SELECT id, nombre_completo, dni FROM clientes ORDER BY nombre_completo")->fetchAll();

?>

<style>
    .kanban-board {
        display: flex;
        gap: 20px;
        overflow-x: auto;
        padding-bottom: 20px;
        align-items: flex-start;
    }
    .kanban-column {
        flex: 0 0 300px;
        background: var(--surface-color);
        border-radius: 12px;
        border: 1px solid var(--border-color);
        display: flex;
        flex-direction: column;
        max-height: calc(100vh - 250px);
    }
    .kanban-header {
        padding: 15px;
        font-weight: 700;
        border-bottom: 1px solid var(--border-color);
        display: flex;
        justify-content: space-between;
        align-items: center;
        text-transform: uppercase;
        font-size: 0.9rem;
    }
    .kanban-header .badge {
        background: var(--bg-color);
        color: var(--text-color);
        border-radius: 50%;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.8rem;
    }
    .kanban-body {
        padding: 15px;
        overflow-y: auto;
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    .ticket-card {
        background: var(--bg-color);
        border: 1px solid var(--border-color);
        border-radius: 10px;
        padding: 15px;
        cursor: pointer;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .ticket-card:hover {
        transform: translateY(-2px);
        box-shadow: var(--shadow);
    }
    body.dark-theme .ticket-card {
        background: #1e293b;
    }
    .ticket-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }
    .ticket-id {
        font-size: 0.8rem;
        font-weight: 700;
        color: var(--text-muted);
    }
    .ticket-title {
        font-weight: 600;
        margin-bottom: 8px;
        font-size: 0.95rem;
        line-height: 1.3;
    }
    .ticket-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 10px;
        font-size: 0.8rem;
    }
    .ticket-tag {
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: 600;
        font-size: 0.75rem;
    }
    .ticket-assignee {
        display: flex;
        align-items: center;
        gap: 5px;
        color: var(--text-muted);
    }
    .ticket-assignee i {
        font-size: 1rem;
    }
    .filter-bar {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 24px;
        background: var(--surface-color);
        padding: 16px;
        border-radius: 12px;
        border: 1px solid var(--border-color);
        box-shadow: var(--shadow);
        align-items: center;
    }
    
    .status-abierto { border-top: 3px solid #3b82f6; }
    .status-pendiente { border-top: 3px solid #eab308; }
    .status-en_proceso { border-top: 3px solid #8b5cf6; }
    .status-terminado { border-top: 3px solid #10b981; }

    /* Custom scrollbar para kanban */
    .kanban-body::-webkit-scrollbar { width: 6px; }
    .kanban-body::-webkit-scrollbar-thumb { background-color: var(--border-color); border-radius: 10px; }

    /* Chat Offcanvas */
    .chat-offcanvas {
        position: fixed;
        top: 0;
        right: -450px;
        width: 400px;
        height: 100vh;
        background: url('../../assets/img/chat-bg.png') repeat, var(--surface-color);
        background-color: #efeae2;
        box-shadow: -5px 0 15px rgba(0,0,0,0.1);
        z-index: 1050;
        transition: right 0.3s ease;
        display: flex;
        flex-direction: column;
        border-left: 1px solid var(--border-color);
    }
    body.dark-theme .chat-offcanvas {
        background-color: #0b141a;
        background-image: none;
    }
    .chat-offcanvas.open {
        right: 0;
    }
    .chat-header {
        padding: 15px;
        background: var(--surface-color);
        border-bottom: 1px solid var(--border-color);
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .chat-messages {
        flex: 1;
        padding: 20px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    .message-bubble {
        max-width: 75%;
        padding: 10px 15px;
        border-radius: 12px;
        position: relative;
        font-size: 0.95rem;
        line-height: 1.4;
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
        word-wrap: break-word;
    }
    .message-received {
        align-self: flex-start;
        background: #ffffff;
        color: #111b21;
        border-top-left-radius: 0;
    }
    .message-sent {
        align-self: flex-end;
        background: #d9fdd3;
        color: #111b21;
        border-top-right-radius: 0;
    }
    body.dark-theme .message-received { background: #202c33; color: #e9edef; }
    body.dark-theme .message-sent { background: #005c4b; color: #e9edef; }
    .message-time {
        font-size: 0.65rem;
        color: rgba(0,0,0,0.45);
        text-align: right;
        margin-top: 5px;
        display: block;
    }
    body.dark-theme .message-time { color: rgba(255,255,255,0.6); }
    
    .chat-input-area {
        padding: 15px;
        background: var(--surface-color);
        border-top: 1px solid var(--border-color);
        display: flex;
        align-items: flex-end;
        gap: 10px;
    }
    .chat-input-wrapper {
        flex: 1;
        background: var(--bg-color);
        border-radius: 20px;
        padding: 0 15px;
        border: 1px solid var(--border-color);
    }
    .chat-input-wrapper textarea {
        width: 100%;
        border: none;
        background: transparent;
        padding: 12px 0;
        max-height: 120px;
        outline: none;
        resize: none;
        color: var(--text-color);
        font-family: inherit;
    }
    .btn-send {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        background: #00a884;
        color: white;
        border: none;
        font-size: 1.2rem;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        flex-shrink: 0;
    }
    .unread-badge {
        background: #ef4444;
        color: white;
        font-size: 0.75rem;
        font-weight: bold;
        padding: 2px 6px;
        border-radius: 10px;
        margin-left: 5px;
    }
</style>

<div class="page-header-card">
    <div class="page-header-left">
        <div class="page-header-icon">
            <i class="ph ph-headset"></i>
        </div>
        <div class="page-header-info">
            <h2>Soporte</h2>
            <p>Gestión de tickets y atención al cliente.</p>
        </div>
    </div>
    <div class="page-header-actions">
        <button type="button" class="btn btn-secondary" onclick="openAjustesModal()">
            <i class="ph ph-gear"></i> Ajustes
        </button>
        <button type="button" class="btn btn-primary" onclick="openNuevoTicketModal()">
            <i class="ph ph-plus"></i> Nuevo Ticket
        </button>
    </div>
</div>

<div class="filter-bar">
    <div class="search-box position-relative flex-grow-1" style="min-width: 250px;">
        <i class="ph ph-magnifying-glass position-absolute" style="left: 16px; top: 50%; transform: translateY(-50%); color: var(--text-muted);"></i>
        <input type="text" id="searchInput" class="form-control" placeholder="Buscar ticket por asunto o cliente..." style="padding-left: 40px;">
    </div>
    <select class="form-select" id="filterCategoria" style="width: auto;">
        <option value="">Todas las Categorías</option>
        <?php foreach($categorias as $cat): ?>
            <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
        <?php endforeach; ?>
    </select>
    <select class="form-select" id="filterPrioridad" style="width: auto;">
        <option value="">Todas las Prioridades</option>
        <?php foreach($prioridades as $pri): ?>
            <option value="<?php echo $pri['id']; ?>"><?php echo htmlspecialchars($pri['name']); ?></option>
        <?php endforeach; ?>
    </select>
    <button class="btn btn-outline-secondary" onclick="loadTickets()"><i class="ph ph-arrows-clockwise"></i> Refrescar</button>
</div>

<div class="kanban-board">
    <!-- NUEVO -->
    <div class="kanban-column status-nuevo">
        <div class="kanban-header">
            <span style="border-bottom: 3px solid #3b82f6;">NUEVO</span>
            <span class="badge" id="count-nuevo">0</span>
        </div>
        <div class="kanban-body" id="col-nuevo"></div>
    </div>
    <!-- PENDIENTE -->
    <div class="kanban-column status-pendiente">
        <div class="kanban-header">
            <span>Pendiente</span>
            <span class="badge" id="count-pendiente">0</span>
        </div>
        <div class="kanban-body" id="col-pendiente"></div>
    </div>
    <!-- EN PROCESO -->
    <div class="kanban-column status-en_proceso">
        <div class="kanban-header">
            <span>En Proceso</span>
            <span class="badge" id="count-en_proceso">0</span>
        </div>
        <div class="kanban-body" id="col-en_proceso"></div>
    </div>
    <!-- TERMINADO -->
    <div class="kanban-column status-terminado">
        <div class="kanban-header">
            <span>Terminado</span>
            <span class="badge" id="count-terminado">0</span>
        </div>
        <div class="kanban-body" id="col-terminado"></div>
    </div>
</div>

<!-- Modal Nuevo Ticket -->
<div class="modal-overlay" id="ticketModal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h3 id="ticketModalTitle">Nuevo Ticket</h3>
            <button class="btn close-modal" style="background:transparent; border:none; font-size:1.5rem; cursor:pointer;" onclick="document.getElementById('ticketModal').classList.remove('active')">&times;</button>
        </div>
        <form id="ticketForm">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Cliente</label>
                        <select name="cliente_id" class="form-select" required>
                            <option value="">Seleccione un cliente...</option>
                            <?php foreach($clientes as $cli): ?>
                                <option value="<?php echo $cli['id']; ?>"><?php echo htmlspecialchars($cli['nombre_completo'] . ' (' . $cli['dni'] . ')'); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Asunto</label>
                        <input type="text" name="asunto" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Categoría</label>
                        <select name="categoria_id" class="form-select">
                            <option value="">Sin Categoría</option>
                            <?php foreach($categorias as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Prioridad</label>
                        <select name="prioridad_id" class="form-select">
                            <option value="">Sin Prioridad</option>
                            <?php foreach($prioridades as $pri): ?>
                                <option value="<?php echo $pri['id']; ?>"><?php echo htmlspecialchars($pri['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Asignar a (Técnico)</label>
                        <select name="assigned_to" class="form-select">
                            <option value="">Sin Asignar</option>
                            <?php foreach($tecnicos as $tec): ?>
                                <option value="<?php echo $tec['id']; ?>"><?php echo htmlspecialchars($tec['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Descripción del Problema</label>
                        <textarea name="descripcion" class="form-control" rows="4" required></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('ticketModal').classList.remove('active')">Cancelar</button>
                <button type="submit" class="btn btn-primary">Crear Ticket</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Ajustes -->
<div class="modal-overlay" id="ajustesModal">
    <div class="modal-content" style="max-width: 800px;">
        <div class="modal-header">
            <h3>Ajustes de Soporte</h3>
            <button class="btn close-modal" style="background:transparent; border:none; font-size:1.5rem; cursor:pointer;" onclick="document.getElementById('ajustesModal').classList.remove('active')">&times;</button>
        </div>
        <div class="modal-body">
            <ul class="nav nav-tabs" style="margin-bottom: 20px; border-bottom: 1px solid var(--border-color); display: flex; list-style: none; padding: 0;">
                <li style="margin-right: 10px;">
                    <button type="button" class="btn btn-outline-primary active" id="tabCat" onclick="switchTab('cat')">Categorías</button>
                </li>
                <li>
                    <button type="button" class="btn btn-outline-primary" id="tabPri" onclick="switchTab('pri')">Prioridades</button>
                </li>
            </ul>
            
            <!-- Tab Categorías -->
            <div id="contentCat">
                <form id="catForm" class="d-flex gap-2 mb-3">
                    <input type="text" name="name" class="form-control" placeholder="Nueva Categoría" required>
                    <input type="color" name="color" class="form-control" style="width: 50px; padding: 0;" value="#3b82f6">
                    <button type="submit" class="btn btn-primary">Añadir</button>
                </form>
                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th>Nombre</th><th>Color</th><th>Acciones</th></tr></thead>
                        <tbody id="catTableBody">
                            <?php foreach($categorias as $cat): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($cat['name']); ?></td>
                                <td><div style="width: 20px; height: 20px; background: <?php echo $cat['color']; ?>; border-radius: 4px;"></div></td>
                                <td><button class="btn btn-sm btn-danger" onclick="deleteSetting('category', <?php echo $cat['id']; ?>)">Eliminar</button></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Tab Prioridades -->
            <div id="contentPri" style="display: none;">
                <form id="priForm" class="d-flex gap-2 mb-3">
                    <input type="text" name="name" class="form-control" placeholder="Nueva Prioridad" required>
                    <input type="color" name="color" class="form-control" style="width: 50px; padding: 0;" value="#eab308">
                    <input type="number" name="level" class="form-control" placeholder="Nivel (Ej: 1, 2, 3)" style="width: 100px;" value="1" required>
                    <button type="submit" class="btn btn-primary">Añadir</button>
                </form>
                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th>Nombre</th><th>Nivel</th><th>Color</th><th>Acciones</th></tr></thead>
                        <tbody id="priTableBody">
                            <?php foreach($prioridades as $pri): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($pri['name']); ?></td>
                                <td><?php echo $pri['level']; ?></td>
                                <td><div style="width: 20px; height: 20px; background: <?php echo $pri['color']; ?>; border-radius: 4px;"></div></td>
                                <td><button class="btn btn-sm btn-danger" onclick="deleteSetting('priority', <?php echo $pri['id']; ?>)">Eliminar</button></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>

<!-- Chat Offcanvas -->
<div class="chat-offcanvas" id="chatSidebar">
    <div class="chat-header" style="flex-direction: column; align-items: stretch; padding: 10px 15px;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-weight: bold;" id="chatAvatar">C</div>
                <div>
                    <div style="font-weight: bold; font-size: 0.95rem; line-height: 1.1;" id="chatTitle">Cliente</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted);" id="chatSubtitle">TKT-0000</div>
                </div>
            </div>
            <div style="display: flex; gap: 5px;">
                <a href="#" target="_blank" id="btnWhatsapp" class="btn btn-sm" style="background:#25D366; color:white; padding: 5px; border-radius: 50%;" title="WhatsApp"><i class="ph-fill ph-whatsapp-logo" style="font-size:1.2rem;"></i></a>
                <a href="#" id="btnCall" class="btn btn-sm" style="background:#3b82f6; color:white; padding: 5px; border-radius: 50%;" title="Llamar"><i class="ph-fill ph-phone" style="font-size:1.2rem;"></i></a>
                <a href="#" target="_blank" id="btnMap" class="btn btn-sm" style="background:#ef4444; color:white; padding: 5px; border-radius: 50%;" title="Ubicación"><i class="ph-fill ph-map-pin" style="font-size:1.2rem;"></i></a>
                <button class="btn close-modal" style="background:transparent; border:none; font-size:1.5rem; cursor:pointer; padding: 0 5px;" onclick="closeChat()">&times;</button>
            </div>
        </div>
        <div style="display: flex; gap: 10px; border-top: 1px solid var(--border-color); padding-top: 10px;">
            <select id="chatAssignSelect" class="form-select" style="padding: 4px 8px; font-size: 0.8rem;" onchange="updateTicketAssignee(this.value)">
                <option value="">Sin Asignar</option>
                <?php foreach($tecnicos as $tec): ?>
                    <option value="<?php echo $tec['id']; ?>"><?php echo htmlspecialchars($tec['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <select id="chatStatusSelect" class="form-select" style="padding: 4px 8px; font-size: 0.8rem;" onchange="updateTicketStatus(this.value)">
                <option value="nuevo">Nuevo</option>
                <option value="pendiente">Pendiente</option>
                <option value="en_proceso">En Proceso</option>
                <option value="terminado">Terminado</option>
            </select>
        </div>
    </div>
    <div class="chat-messages" id="chatMessages">
        <!-- Mensajes -->
    </div>
    <div class="chat-input-area" style="position: relative;">
        <!-- Menú de Acciones Flotante -->
        <div id="chatActionMenu" style="display: none; position: absolute; bottom: 100%; left: 15px; margin-bottom: 10px; background: white; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border: 1px solid var(--border-color); padding: 10px; z-index: 100;">
            <button onclick="chatFileInput.click(); toggleActionMenu();" style="display: flex; align-items: center; gap: 10px; width: 100%; padding: 8px 12px; background: transparent; border: none; text-align: left; cursor: pointer; border-radius: 8px; font-size: 0.9rem;" onmouseover="this.style.background='#f1f5f9'" onmouseout="this.style.background='transparent'">
                <i class="ph-fill ph-camera" style="font-size: 1.2rem; color: #3b82f6;"></i> Enviar Foto
            </button>
            <button onclick="sendLocation(); toggleActionMenu();" style="display: flex; align-items: center; gap: 10px; width: 100%; padding: 8px 12px; background: transparent; border: none; text-align: left; cursor: pointer; border-radius: 8px; font-size: 0.9rem;" onmouseover="this.style.background='#f1f5f9'" onmouseout="this.style.background='transparent'">
                <i class="ph-fill ph-map-pin" style="font-size: 1.2rem; color: #ef4444;"></i> Enviar Ubicación
            </button>
        </div>

        <button onclick="toggleActionMenu()" style="background: transparent; border: none; font-size: 1.5rem; color: var(--text-muted); cursor: pointer; padding: 0 10px;">
            <i class="ph ph-plus-circle"></i>
        </button>
        
        <div id="filePreviewContainer" style="display: none; position: absolute; bottom: 100%; left: 50px; margin-bottom: 8px; background: #3b82f6; color: white; padding: 6px 12px; border-radius: 20px; font-size: 0.8rem; align-items: center; gap: 8px; box-shadow: 0 2px 8px rgba(59,130,246,0.3); z-index: 50;">
            <i class="ph-fill ph-image"></i>
            <span id="filePreviewName" style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 500;"></span>
            <button onclick="clearFileSelection()" style="background: rgba(255,255,255,0.2); border:none; color:white; cursor:pointer; padding: 2px; border-radius: 50%; display:flex; align-items:center; justify-content:center; width: 18px; height: 18px;"><i class="ph-bold ph-x" style="font-size: 0.6rem;"></i></button>
        </div>
        
        <div class="chat-input-wrapper" style="flex: 1; display: flex; flex-direction: column;">
            <textarea id="messageInput" placeholder="Escribe un mensaje..." rows="1" oninput="this.style.height = ''; this.style.height = this.scrollHeight + 'px'; updateMainButton();"></textarea>
        </div>
        
        <div id="audioRecordingUi" style="display: none; flex: 1; align-items: center; justify-content: space-between; background: #fee2e2; border-radius: 20px; padding: 0 15px; border: 1px solid #fca5a5; height: 40px;">
            <div style="display: flex; align-items: center; gap: 10px; color: #ef4444; font-weight: bold; font-size: 0.9rem;">
                <div style="width: 10px; height: 10px; background: #ef4444; border-radius: 50%; animation: pulse-red 1s infinite;"></div>
                <span id="recordingTimer">00:00</span>
            </div>
            <button onclick="cancelRecording()" style="background: transparent; border: none; color: #ef4444; cursor: pointer; font-size: 1.2rem;"><i class="ph-fill ph-trash"></i></button>
        </div>

        <button class="btn-send" onclick="handleMainAction()" id="btnSendMessage"><i id="btnSendMessageIcon" class="ph-fill ph-microphone"></i></button>
    </div>
</div>

<!-- Lightbox Modal -->
<div id="imageLightbox" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:99999; align-items:center; justify-content:center; flex-direction:column; backdrop-filter: blur(5px);">
    <button onclick="document.getElementById('imageLightbox').style.display='none'" style="position:absolute; top:20px; right:20px; background:rgba(255,255,255,0.1); border:none; color:white; font-size:1.5rem; cursor:pointer; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: background 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.2)'" onmouseout="this.style.background='rgba(255,255,255,0.1)'"><i class="ph-bold ph-x"></i></button>
    <img id="lightboxImg" style="max-width:90%; max-height:90%; border-radius:12px; box-shadow: 0 10px 40px rgba(0,0,0,0.5); object-fit: contain;">
</div>

<style>
    @keyframes pulse-red {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.5); opacity: 0.5; }
        100% { transform: scale(1); opacity: 1; }
    }
    .sys-message {
        text-align: center;
        margin: 10px 0;
        font-size: 0.75rem;
        color: #64748b;
        background: rgba(0,0,0,0.05);
        padding: 5px 15px;
        border-radius: 20px;
        align-self: center;
        display: inline-block;
    }
    .loc-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 10px;
        margin-top: 5px;
        display: flex;
        align-items: center;
        gap: 10px;
        text-decoration: none;
        color: inherit;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .loc-card:hover { background: #f1f5f9; }
</style>

<script>
    let ticketsData = [];
    let currentChatId = null;
    let lastMessageId = 0;
    const currentUserId = <?php echo $_SESSION['user_id']; ?>;

    const loadTickets = async () => {
        try {
            const formData = new FormData();
            formData.append('action', 'list');
            const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', {
                method: 'POST',
                body: formData
            }).then(r => r.json());
            if (res.success) {
                ticketsData = res.data;
                renderKanban();
            }
        } catch (e) {
            console.error(e);
        }
    };

    const renderKanban = () => {
        const search = document.getElementById('searchInput').value.toLowerCase();
        const catFilter = document.getElementById('filterCategoria').value;
        const priFilter = document.getElementById('filterPrioridad').value;

        const filtered = ticketsData.filter(t => {
            const matchSearch = (t.asunto && t.asunto.toLowerCase().includes(search)) || (t.cliente_nombre && t.cliente_nombre.toLowerCase().includes(search));
            const matchCat = catFilter === '' || t.categoria_id == catFilter;
            const matchPri = priFilter === '' || t.prioridad_id == priFilter;
            return matchSearch && matchCat && matchPri;
        });

        const columns = ['nuevo', 'pendiente', 'en_proceso', 'terminado'];
        columns.forEach(col => {
            document.getElementById(`col-${col}`).innerHTML = '';
            document.getElementById(`count-${col}`).innerText = '0';
        });

        filtered.forEach(t => {
            const container = document.getElementById(`col-${t.estado}`);
            if(!container) return;

            let catHtml = t.cat_name ? `<span class="ticket-tag" style="background:${t.cat_color}20; color:${t.cat_color};">${t.cat_name}</span>` : '';
            let priHtml = t.pri_name ? `<span class="ticket-tag" style="background:${t.pri_color}20; color:${t.pri_color};">${t.pri_name}</span>` : '';
            let assignHtml = t.tech_name ? `<div class="ticket-assignee"><i class="ph ph-user"></i> ${t.tech_name}</div>` : `<div class="ticket-assignee">Sin asignar</div>`;
            let unreadHtml = (t.unread_count && t.unread_count > 0) ? `<span class="unread-badge">${t.unread_count}</span>` : '';

            const card = document.createElement('div');
            card.className = 'ticket-card';
            card.onclick = () => openChat(t);
            card.innerHTML = `
                <div class="ticket-header">
                    <span class="ticket-id">#TKT-${t.id.toString().padStart(4, '0')}</span>
                    ${priHtml}
                </div>
                <div class="ticket-title">${t.asunto} ${unreadHtml}</div>
                <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 10px;">
                    <i class="ph-fill ph-user-circle"></i> ${t.cliente_nombre || 'Cliente Anónimo'}
                </div>
                <div class="ticket-meta">
                    ${catHtml}
                    ${assignHtml}
                </div>
            `;
            container.appendChild(card);
            
            const countEl = document.getElementById(`count-${t.estado}`);
            countEl.innerText = parseInt(countEl.innerText) + 1;
        });
    };

    document.getElementById('searchInput').addEventListener('input', renderKanban);
    document.getElementById('filterCategoria').addEventListener('change', renderKanban);
    document.getElementById('filterPrioridad').addEventListener('change', renderKanban);

    // Modal Nuevo Ticket
    const openNuevoTicketModal = () => {
        document.getElementById('ticketForm').reset();
        document.getElementById('ticketModal').classList.add('active');
    };

    document.getElementById('ticketForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        formData.append('action', 'save');
        try {
            const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', {
                method: 'POST',
                body: formData
            }).then(r => r.json());
            if (res.success) {
                window.showToast('Ticket creado exitosamente', 'success');
                document.getElementById('ticketModal').classList.remove('active');
                loadTickets();
            } else {
                window.showToast(res.message, 'error');
            }
        } catch (err) {
            window.showToast('Error del servidor', 'error');
        }
    });

    // Ajustes
    const openAjustesModal = () => {
        document.getElementById('ajustesModal').classList.add('active');
    };

    const switchTab = (tab) => {
        if(tab === 'cat') {
            document.getElementById('contentCat').style.display = 'block';
            document.getElementById('contentPri').style.display = 'none';
            document.getElementById('tabCat').classList.add('active');
            document.getElementById('tabPri').classList.remove('active');
        } else {
            document.getElementById('contentCat').style.display = 'none';
            document.getElementById('contentPri').style.display = 'block';
            document.getElementById('tabCat').classList.remove('active');
            document.getElementById('tabPri').classList.add('active');
        }
    };

    document.getElementById('catForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        fd.append('action', 'save_category');
        try {
            const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
            if(res.success) location.reload(); else window.showToast(res.message, 'error');
        } catch(err) {}
    });

    document.getElementById('priForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        fd.append('action', 'save_priority');
        try {
            const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
            if(res.success) location.reload(); else window.showToast(res.message, 'error');
        } catch(err) {}
    });

    window.deleteSetting = async (type, id) => {
        if(confirm('¿Seguro que desea eliminar este elemento?')) {
            const fd = new FormData();
            fd.append('action', type === 'category' ? 'delete_category' : 'delete_priority');
            fd.append('id', id);
            try {
                const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
                if(res.success) location.reload(); else window.showToast(res.message, 'error');
            } catch(err) {}
        }
    };

    document.addEventListener('DOMContentLoaded', () => {
        loadTickets();
        setInterval(loadTickets, 10000); // Poll kanban updates
        setInterval(loadMessages, 3000); // Poll chat messages
        
        document.getElementById('messageInput').addEventListener('keydown', (e) => {
            if(e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    });

    const formatTime = (dateStr) => {
        const d = new Date(dateStr);
        return d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    };

    const openChat = (ticket) => {
        currentChatId = ticket.id;
        lastMessageId = 0;
        const clientName = ticket.cliente_nombre || 'Cliente Anónimo';
        document.getElementById('chatAvatar').innerText = clientName.substring(0,1).toUpperCase();
        document.getElementById('chatTitle').innerText = clientName;
        document.getElementById('chatSubtitle').innerText = `TKT-${ticket.id.toString().padStart(4, '0')}`;
        
        // Cargar botones de contacto
        const btnWsp = document.getElementById('btnWhatsapp');
        const btnCall = document.getElementById('btnCall');
        const btnMap = document.getElementById('btnMap');
        
        if (ticket.cliente_celular) {
            btnWsp.href = `https://wa.me/${ticket.cliente_celular.replace(/\D/g, '')}`;
            btnWsp.style.display = 'inline-flex';
            btnCall.href = `tel:${ticket.cliente_celular}`;
            btnCall.style.display = 'inline-flex';
        } else {
            btnWsp.style.display = 'none';
            btnCall.style.display = 'none';
        }

        if (ticket.cliente_direccion) {
            btnMap.href = `https://maps.google.com/?q=${encodeURIComponent(ticket.cliente_direccion)}`;
            btnMap.style.display = 'inline-flex';
        } else {
            btnMap.style.display = 'none';
        }

        // Cargar selects
        document.getElementById('chatAssignSelect').value = ticket.assigned_to || '';
        document.getElementById('chatStatusSelect').value = ticket.estado;

        document.getElementById('chatMessages').innerHTML = '';
        document.getElementById('chatSidebar').classList.add('open');
        
        // Handle input area visibility dynamically
        const inputArea = document.querySelector('.chat-input-area');
        if (ticket.estado === 'terminado') {
            inputArea.style.display = 'none';
            if (!document.getElementById('terminatedWarningAdmin')) {
                inputArea.insertAdjacentHTML('beforebegin', '<div id="terminatedWarningAdmin" style="text-align:center; padding:15px; color:#ef4444; font-weight:bold; background:#fee2e2; border-top:1px solid #fca5a5;">El ticket está TERMINADO. No puedes enviar más mensajes.</div>');
            }
            document.getElementById('terminatedWarningAdmin').style.display = 'block';
        } else {
            inputArea.style.display = 'flex';
            if (document.getElementById('terminatedWarningAdmin')) document.getElementById('terminatedWarningAdmin').style.display = 'none';
        }
        
        // Auto-change to en_proceso if it is nuevo
        if (ticket.estado === 'nuevo') {
            updateTicketStatus('en_proceso', false);
            ticket.estado = 'en_proceso';
            document.getElementById('chatStatusSelect').value = 'en_proceso';
        }
        
        // Mark as read immediately
        const fd = new FormData();
        fd.append('action', 'mark_as_read');
        fd.append('ticket_id', ticket.id);
        fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json()).then(()=>{
            loadTickets(); // Refresh badges
            loadMessages();
        });
    };

    const updateTicketStatus = async (status, reload = true) => {
        if(!currentChatId) return;
        const fd = new FormData();
        fd.append('action', 'update_status');
        fd.append('ticket_id', currentChatId);
        fd.append('estado', status);
        const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
        
        // Handle input area visibility dynamically
        const inputArea = document.querySelector('.chat-input-area');
        if (status === 'terminado') {
            inputArea.style.display = 'none';
            if (!document.getElementById('terminatedWarningAdmin')) {
                inputArea.insertAdjacentHTML('beforebegin', '<div id="terminatedWarningAdmin" style="text-align:center; padding:15px; color:#ef4444; font-weight:bold; background:#fee2e2; border-top:1px solid #fca5a5;">El ticket está TERMINADO. No puedes enviar más mensajes.</div>');
            }
            document.getElementById('terminatedWarningAdmin').style.display = 'block';
        } else {
            inputArea.style.display = 'flex';
            if (document.getElementById('terminatedWarningAdmin')) document.getElementById('terminatedWarningAdmin').style.display = 'none';
        }
        
        if(res.success && reload) {
            window.showToast('Estado actualizado', 'success');
            loadTickets();
        }
    };

    const updateTicketAssignee = async (assignee) => {
        if(!currentChatId) return;
        const fd = new FormData();
        fd.append('action', 'assign_ticket');
        fd.append('ticket_id', currentChatId);
        fd.append('assigned_to', assignee);
        const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
        if(res.success) {
            window.showToast('Asignación actualizada', 'success');
            loadTickets();
        }
    };

    const closeChat = () => {
        document.getElementById('chatSidebar').classList.remove('open');
        currentChatId = null;
    };

    let isPollingMessages = false;
    const loadMessages = async () => {
        if(!currentChatId || isPollingMessages) return;
        isPollingMessages = true;
        try {
            const fd = new FormData();
            fd.append('action', 'get_messages');
            fd.append('ticket_id', currentChatId);
            fd.append('last_id', lastMessageId);

            const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
            if(res.success && res.data.length > 0) {
                const container = document.getElementById('chatMessages');
                res.data.forEach(msg => {
                    if (msg.is_system_message == 1) {
                        container.innerHTML += `<div class="sys-message">${msg.message}</div>`;
                    } else {
                        const isMe = msg.user_id == currentUserId;
                        const bubbleClass = isMe ? 'message-sent' : 'message-received';
                        const userName = isMe ? 'Tú' : (msg.user_name || 'Cliente');
                        
                        let msgContent = msg.message.replace(/\n/g, '<br>');
                        
                        // Parse Location
                        if (msgContent.startsWith('[LOCATION:') && msgContent.endsWith(']')) {
                            const coords = msgContent.replace('[LOCATION:', '').replace(']', '');
                            msgContent = `
                                <a href="https://maps.google.com/?q=${coords}" target="_blank" class="loc-card">
                                    <div style="background: #ef4444; color: white; padding: 10px; border-radius: 8px;"><i class="ph-fill ph-map-pin" style="font-size: 1.5rem;"></i></div>
                                    <div>
                                        <div style="font-weight: 600; font-size: 0.9rem;">Ubicación compartida</div>
                                        <div style="font-size: 0.75rem; color: #64748b;">Toca para abrir el mapa</div>
                                    </div>
                                </a>
                            `;
                        }

                        // Attachments
                        let attHtml = '';
                        if (msg.attachments && msg.attachments.length > 0) {
                            msg.attachments.forEach(att => {
                                const url = `${'<?php echo BASE_URL; ?>/'}${att.file_path}`;
                                const ext = att.file_name.split('.').pop().toLowerCase();
                                if (['webm', 'mp3', 'ogg', 'wav', 'm4a'].includes(ext)) {
                                    attHtml += `<audio controls src="${url}" style="max-width: 100%; margin-top: 5px; outline: none; height: 35px;"></audio>`;
                                } else {
                                    attHtml += `<img src="${url}" onclick="openLightbox('${url}')" style="cursor: pointer; max-width: 100%; border-radius: 8px; margin-top: 5px; border: 1px solid rgba(0,0,0,0.1); transition: opacity 0.2s;" onmouseover="this.style.opacity=0.9" onmouseout="this.style.opacity=1">`;
                                }
                            });
                        }
                        
                        container.innerHTML += `
                            <div class="message-bubble ${bubbleClass}">
                                ${!isMe ? `<div style="font-size:0.75rem; font-weight:700; color:var(--primary-color); margin-bottom:3px;">${userName}</div>` : ''}
                                <div>${msgContent}</div>
                                ${attHtml}
                                <span class="message-time">${formatTime(msg.created_at)}</span>
                            </div>
                        `;
                    }
                    lastMessageId = msg.id;
                });
                container.scrollTop = container.scrollHeight;
                
                // Si cargó nuevos mensajes, refrescar los tickets para que se quite el globo rojo si estamos leyendo.
                loadTickets();
            }
        } catch(e) {}
        isPollingMessages = false;
    };

    const stopPollingMessages = () => {
        isPollingMessages = false;
    };

    // Lightbox handling
    const openLightbox = (src) => {
        document.getElementById('lightboxImg').src = src;
        document.getElementById('imageLightbox').style.display = 'flex';
    };

    let selectedFile = null;
    
    // Create file input dynamically to avoid global UI plugins (like Dropify) auto-initializing it
    const chatFileInput = document.createElement('input');
    chatFileInput.type = 'file';
    chatFileInput.accept = 'image/*';
    chatFileInput.capture = 'environment';
    chatFileInput.onchange = (e) => handleFileSelect(e.target);

    const toggleActionMenu = () => {
        const menu = document.getElementById('chatActionMenu');
        menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
    };

    const clearFileSelection = () => {
        selectedFile = null;
        chatFileInput.value = '';
        document.getElementById('filePreviewContainer').style.display = 'none';
        updateMainButton();
    };

    const handleFileSelect = (input) => {
        if (input.files && input.files[0]) {
            selectedFile = input.files[0];
            document.getElementById('filePreviewName').innerText = selectedFile.name;
            document.getElementById('filePreviewContainer').style.display = 'flex';
            updateMainButton();
        }
    };

    const sendLocation = () => {
        if (!navigator.geolocation) {
            window.showToast('Tu navegador no soporta geolocalización', 'error');
            return;
        }
        navigator.geolocation.getCurrentPosition(
            async (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                const fd = new FormData();
                fd.append('action', 'send_message');
                fd.append('ticket_id', currentChatId);
                fd.append('message', `[LOCATION:${lat},${lng}]`);
                try {
                    const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
                    if(res.success) loadMessages();
                } catch(e) {}
            },
            (error) => {
                window.showToast('No se pudo obtener la ubicación', 'error');
            }
        );
    };

    // Voice Notes Logic
    let isRecording = false;
    let mediaRecorder = null;
    let audioChunks = [];
    let recordingTimerInterval = null;
    let recordingSeconds = 0;

    const updateMainButton = () => {
        const text = document.getElementById('messageInput').value.trim();
        const btnIcon = document.getElementById('btnSendMessageIcon');
        if (text || selectedFile) {
            btnIcon.className = 'ph-fill ph-paper-plane-right';
        } else {
            btnIcon.className = 'ph-fill ph-microphone';
        }
    };

    const handleMainAction = () => {
        const text = document.getElementById('messageInput').value.trim();
        if (text || selectedFile) {
            sendMessage();
        } else {
            if (isRecording) {
                stopRecordingAndSend();
            } else {
                startRecording();
            }
        }
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            audioChunks = [];
            
            mediaRecorder.addEventListener("dataavailable", event => {
                audioChunks.push(event.data);
            });
            
            mediaRecorder.addEventListener("stop", () => {
                if (isRecording) {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    sendAudioMessage(audioBlob);
                }
                isRecording = false;
                stream.getTracks().forEach(track => track.stop());
                
                document.getElementById('audioRecordingUi').style.display = 'none';
                document.querySelector('.chat-input-wrapper').style.display = 'flex';
                updateMainButton();
                clearInterval(recordingTimerInterval);
            });
            
            isRecording = true;
            mediaRecorder.start();
            
            document.querySelector('.chat-input-wrapper').style.display = 'none';
            document.getElementById('audioRecordingUi').style.display = 'flex';
            document.getElementById('btnSendMessageIcon').className = 'ph-fill ph-paper-plane-right';
            
            recordingSeconds = 0;
            document.getElementById('recordingTimer').innerText = '00:00';
            recordingTimerInterval = setInterval(() => {
                recordingSeconds++;
                const m = String(Math.floor(recordingSeconds / 60)).padStart(2, '0');
                const s = String(recordingSeconds % 60).padStart(2, '0');
                document.getElementById('recordingTimer').innerText = `${m}:${s}`;
            }, 1000);
            
        } catch (e) {
            window.showToast('No se pudo acceder al micrófono. Verifica los permisos.', 'error');
        }
    };

    const cancelRecording = () => {
        isRecording = false;
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
    };

    const stopRecordingAndSend = () => {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
    };

    const sendAudioMessage = async (audioBlob) => {
        const btnSend = document.getElementById('btnSendMessage');
        btnSend.disabled = true;

        const fd = new FormData();
        fd.append('action', 'send_message');
        fd.append('ticket_id', currentChatId);
        fd.append('message', '');
        fd.append('attachment', audioBlob, 'audio_record.webm');

        try {
            const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
            if(res.success) {
                loadMessages();
            }
        } catch(e) {}
        
        btnSend.disabled = false;
    };

    const sendMessage = async () => {
        const input = document.getElementById('messageInput');
        const text = input.value.trim();
        if((!text && !selectedFile) || !currentChatId) return;

        input.value = '';
        input.style.height = '';
        const btnSend = document.getElementById('btnSendMessage');
        btnSend.disabled = true;

        const fd = new FormData();
        fd.append('action', 'send_message');
        fd.append('ticket_id', currentChatId);
        fd.append('message', text);
        if (selectedFile) {
            fd.append('attachment', selectedFile);
            clearFileSelection();
        }

        try {
            const res = await fetch('<?php echo BASE_URL; ?>/ajax/soporte.php', { method: 'POST', body: fd }).then(r=>r.json());
            if(res.success) {
                loadMessages();
                updateMainButton();
            } else {
                window.showToast(res.message, 'error');
            }
        } catch(e) {}
        
        btnSend.disabled = false;
    };

</script>

<?php include '../../includes/footer.php'; ?>
