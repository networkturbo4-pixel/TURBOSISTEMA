<?php
require_once '../config/db.php';
requireLogin();

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {

        // ── Categorías ──────────────────────────────────────
        case 'list_categories':
            $stmt = $pdo->query("SELECT * FROM inventory_categories ORDER BY name ASC");
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'create_category':
            $name = trim($_POST['name'] ?? '');
            if (!$name) {
                echo json_encode(['success' => false, 'message' => 'El nombre es requerido']);
                break;
            }
            $stmt = $pdo->prepare("INSERT INTO inventory_categories (name) VALUES (?)");
            $stmt->execute([$name]);
            echo json_encode(['success' => true, 'id' => $pdo->lastInsertId(), 'message' => 'Categoría creada']);
            break;

        // ── Productos ───────────────────────────────────────
        case 'list_products':
            $sql = "SELECT p.*, c.name as category_name,
                    (SELECT COUNT(*) FROM inventory_skus WHERE product_id = p.id AND status = 'disponible') as qty_disponible,
                    (SELECT COUNT(*) FROM inventory_skus WHERE product_id = p.id AND status = 'instalado') as qty_instalado,
                    (SELECT COUNT(*) FROM inventory_skus WHERE product_id = p.id AND status = 'malogrado') as qty_malogrado,
                    (SELECT COUNT(*) FROM inventory_skus WHERE product_id = p.id AND status = 'reparado') as qty_reparado
                    FROM inventory_products p
                    LEFT JOIN inventory_categories c ON p.category_id = c.id
                    ORDER BY p.created_at DESC";
            $stmt = $pdo->query($sql);
            $products = $stmt->fetchAll();
            // Para productos bulk, qty_disponible es el total_quantity
            foreach ($products as &$p) {
                if ($p['is_bulk']) {
                    $p['qty_disponible'] = $p['total_quantity'];
                    $p['qty_instalado'] = 0;
                    $p['qty_malogrado'] = 0;
                    $p['qty_reparado'] = 0;
                }
            }
            echo json_encode(['success' => true, 'data' => $products]);
            break;

        case 'create_product':
            $name = trim($_POST['name'] ?? '');
            $category_id = $_POST['category_id'] ?? null;
            $quantity = intval($_POST['quantity'] ?? 0);
            $description = trim($_POST['description'] ?? '');
            $stock_minimo = intval($_POST['stock_minimo'] ?? 10);
            $stock_critico = intval($_POST['stock_critico'] ?? 3);
            $custom_columns = $_POST['custom_columns'] ?? '[]';

            $is_bulk = isset($_POST['is_bulk']) && $_POST['is_bulk'] == '1' ? 1 : 0;
            $unit_type = trim($_POST['unit_type'] ?? 'Unidades');
            $master_sku = trim($_POST['master_sku'] ?? '');

            if (!$name || ($quantity < 1 && !$is_bulk)) {
                echo json_encode(['success' => false, 'message' => 'Nombre y cantidad son requeridos']);
                break;
            }

            if ($category_id === '' || $category_id === null) $category_id = null;

            $pdo->beginTransaction();

            if ($is_bulk) {
                if (empty($master_sku)) {
                    // Generar automáticamente si está vacío
                    $master_sku = 'BLK-' . generateRandomCode(5);
                } else {
                    // Validar unicidad
                    $check = $pdo->prepare("SELECT COUNT(*) FROM inventory_products WHERE master_sku = ?");
                    $check->execute([$master_sku]);
                    if ($check->fetchColumn() > 0) {
                        $pdo->rollBack();
                        echo json_encode(['success' => false, 'message' => 'El SKU maestro ya existe para otro producto a granel']);
                        exit;
                    }
                }
            } else {
                $master_sku = null;
            }

            $stmt = $pdo->prepare("INSERT INTO inventory_products (name, description, category_id, total_quantity, stock_minimo, stock_critico, custom_columns, is_bulk, unit_type, master_sku) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $description, $category_id, $quantity, $stock_minimo, $stock_critico, $custom_columns, $is_bulk, $unit_type, $master_sku]);
            $product_id = $pdo->lastInsertId();

            if (!$is_bulk) {
                // Generar SKUs únicos
                $skus_generated = [];
                $attempts = 0;
                $max_attempts = $quantity * 10;

                while (count($skus_generated) < $quantity && $attempts < $max_attempts) {
                    $code = 'TRB-' . generateRandomCode(6);
                    $check = $pdo->prepare("SELECT COUNT(*) FROM inventory_skus WHERE sku_code = ?");
                    $check->execute([$code]);
                    if ($check->fetchColumn() == 0 && !in_array($code, $skus_generated)) {
                        $skus_generated[] = $code;
                    }
                    $attempts++;
                }

                // Insertar SKUs con custom_data (from preview or empty)
                $cols = json_decode($custom_columns, true) ?: [];
                $preview_data = json_decode($_POST['preview_custom_data'] ?? '[]', true) ?: [];

                $insert = $pdo->prepare("INSERT INTO inventory_skus (product_id, sku_code, status, custom_data) VALUES (?, ?, 'disponible', ?)");
                foreach ($skus_generated as $idx => $sku) {
                    // Use preview data if available for this index, otherwise empty
                    if (isset($preview_data[$idx]) && is_array($preview_data[$idx])) {
                        $customJson = json_encode((object)$preview_data[$idx]);
                    } else {
                        $emptyCustom = new stdClass();
                        foreach ($cols as $col) { $emptyCustom->{$col} = ''; }
                        $customJson = json_encode($emptyCustom);
                    }
                    $insert->execute([$product_id, $sku, $customJson]);
                }
            }

            $pdo->commit();

            echo json_encode([
                'success' => true,
                'message' => $is_bulk ? "Producto a granel guardado" : "Producto creado con {$quantity} SKUs",
                'product_id' => $product_id,
                'skus_count' => $is_bulk ? 0 : count($skus_generated ?? [])
            ]);
            break;

        case 'delete_product':
            $id = intval($_POST['id'] ?? 0);
            if (!$id) {
                echo json_encode(['success' => false, 'message' => 'ID inválido']);
                break;
            }
            $stmt = $pdo->prepare("DELETE FROM inventory_products WHERE id = ?");
            $stmt->execute([$id]);
            echo json_encode(['success' => true, 'message' => 'Producto eliminado']);
            break;

        // ── SKUs ────────────────────────────────────────────
        case 'get_product_skus':
            $product_id = intval($_POST['product_id'] ?? $_GET['product_id'] ?? 0);
            $status_filter = $_POST['status'] ?? $_GET['status'] ?? '';

            $sql = "SELECT s.*, p.name as product_name FROM inventory_skus s
                    JOIN inventory_products p ON s.product_id = p.id
                    WHERE s.product_id = ?";
            $params = [$product_id];

            if ($status_filter) {
                $sql .= " AND s.status = ?";
                $params[] = $status_filter;
            }

            $sql .= " ORDER BY s.id ASC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'update_sku_status':
            $sku_id = intval($_POST['sku_id'] ?? 0);
            $status = $_POST['status'] ?? '';
            $valid = ['disponible', 'instalado', 'malogrado', 'reparado', 'en_transito'];

            if (!$sku_id || !in_array($status, $valid)) {
                echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
                break;
            }

            $stmt = $pdo->prepare("UPDATE inventory_skus SET status = ? WHERE id = ?");
            $stmt->execute([$status, $sku_id]);
            echo json_encode(['success' => true, 'message' => 'Estado actualizado']);
            break;

        case 'update_sku_custom':
            $sku_id = intval($_POST['sku_id'] ?? 0);
            $custom_data = $_POST['custom_data'] ?? '{}';

            if (!$sku_id) {
                echo json_encode(['success' => false, 'message' => 'ID inválido']);
                break;
            }

            $stmt = $pdo->prepare("UPDATE inventory_skus SET custom_data = ? WHERE id = ?");
            $stmt->execute([$custom_data, $sku_id]);
            echo json_encode(['success' => true, 'message' => 'Datos actualizados']);
            break;

        case 'update_sku_code':
            $sku_id = intval($_POST['sku_id'] ?? 0);
            $new_code = trim($_POST['sku_code'] ?? '');

            if (!$sku_id || !$new_code) {
                echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
                break;
            }

            // Check uniqueness
            $check = $pdo->prepare("SELECT COUNT(*) FROM inventory_skus WHERE sku_code = ? AND id != ?");
            $check->execute([$new_code, $sku_id]);
            if ($check->fetchColumn() > 0) {
                echo json_encode(['success' => false, 'message' => 'Ese código SKU ya existe']);
                break;
            }

            $stmt = $pdo->prepare("UPDATE inventory_skus SET sku_code = ? WHERE id = ?");
            $stmt->execute([$new_code, $sku_id]);
            echo json_encode(['success' => true, 'message' => 'SKU actualizado']);
            break;

        case 'search_sku':
            $code = trim($_POST['code'] ?? $_GET['code'] ?? '');
            if (!$code) {
                echo json_encode(['success' => false, 'message' => 'Código requerido']);
                break;
            }

            $stmt = $pdo->prepare("SELECT s.*, p.name as product_name, c.name as category_name,
                                   u.name as assigned_user_name, p.description as product_description,
                                   p.stock_minimo, p.stock_critico, p.custom_columns, p.is_bulk
                                   FROM inventory_skus s
                                   JOIN inventory_products p ON s.product_id = p.id
                                   LEFT JOIN inventory_categories c ON p.category_id = c.id
                                   LEFT JOIN users u ON s.assigned_to = u.id
                                   WHERE s.sku_code = ? OR p.name LIKE ? OR u.name LIKE ? LIMIT 1");
            $stmt->execute([$code, "%$code%", "%$code%"]);
            $result = $stmt->fetch();

            if ($result) {
                echo json_encode(['success' => true, 'data' => $result]);
            } else {
                // Check if it's a bulk product's master_sku
                $stmtBulk = $pdo->prepare("SELECT p.id as product_id, p.master_sku as sku_code, p.name as product_name,
                                           c.name as category_name, p.description as product_description,
                                           p.stock_minimo, p.stock_critico, p.is_bulk, p.total_quantity as stock,
                                           'disponible' as status, p.unit_type
                                           FROM inventory_products p
                                           LEFT JOIN inventory_categories c ON p.category_id = c.id
                                           WHERE p.is_bulk = 1 AND (p.master_sku = ? OR p.name LIKE ?) LIMIT 1");
                $stmtBulk->execute([$code, "%$code%"]);
                $resultBulk = $stmtBulk->fetch();

                if ($resultBulk) {
                    // It's a bulk product. We structure it similarly so the frontend can handle it.
                    // We set is_bulk to 1, and we might not have 'id' (since there's no sku row).
                    // We use product_id as id but with a flag.
                    $resultBulk['id'] = 'bulk_' . $resultBulk['product_id'];
                    echo json_encode(['success' => true, 'data' => $resultBulk]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'SKU no encontrado']);
                }
            }
            break;

        // ── Stock Summary ───────────────────────────────────
        case 'get_stock_summary':
            $total = $pdo->query("SELECT COUNT(*) FROM inventory_skus")->fetchColumn();
            $disponible = $pdo->query("SELECT COUNT(*) FROM inventory_skus WHERE status = 'disponible'")->fetchColumn();
            $instalado = $pdo->query("SELECT COUNT(*) FROM inventory_skus WHERE status = 'instalado'")->fetchColumn();
            $malogrado = $pdo->query("SELECT COUNT(*) FROM inventory_skus WHERE status = 'malogrado'")->fetchColumn();
            $reparado = $pdo->query("SELECT COUNT(*) FROM inventory_skus WHERE status = 'reparado'")->fetchColumn();

            $low_stock = $pdo->query("SELECT COUNT(*) FROM (
                SELECT product_id, COUNT(*) as cnt FROM inventory_skus WHERE status = 'disponible' GROUP BY product_id HAVING cnt <= 5
            ) as low")->fetchColumn();

            echo json_encode(['success' => true, 'data' => [
                'total' => intval($total),
                'disponible' => intval($disponible),
                'instalado' => intval($instalado),
                'malogrado' => intval($malogrado),
                'reparado' => intval($reparado),
                'low_stock' => intval($low_stock)
            ]]);
            break;

        // ── All SKUs (for stock control tab) ────────────────
        case 'list_all_skus':
            $status_filter = $_POST['status'] ?? $_GET['status'] ?? '';
            $product_filter = $_POST['product_id'] ?? $_GET['product_id'] ?? '';
            $search = trim($_POST['search'] ?? $_GET['search'] ?? '');

            $sql = "SELECT s.*, p.name as product_name, c.name as category_name, u.name as assigned_user_name,
                           (SELECT a.cliente_nombre FROM actas a JOIN actas_equipos ae ON a.id = ae.acta_id WHERE ae.serie_mac = s.sku_code ORDER BY a.fecha_creacion DESC LIMIT 1) as acta_cliente,
                           (SELECT MAX(created_at) FROM inventory_entries e WHERE e.sku_id = s.id) as last_history_date
                    FROM inventory_skus s
                    JOIN inventory_products p ON s.product_id = p.id
                    LEFT JOIN inventory_categories c ON p.category_id = c.id
                    LEFT JOIN users u ON s.assigned_to = u.id
                    WHERE 1=1";
            $params = [];

            if ($status_filter) {
                $sql .= " AND s.status = ?";
                $params[] = $status_filter;
            }
            if ($product_filter) {
                $sql .= " AND s.product_id = ?";
                $params[] = intval($product_filter);
            }
            if ($search) {
                $sql .= " AND (s.sku_code LIKE ? OR p.name LIKE ? OR u.name LIKE ?)";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
                $params[] = "%{$search}%";
            }

            $sql .= " ORDER BY s.created_at DESC LIMIT 500";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        // ── Users list (for assignment) ─────────────────────
        case 'list_users':
            $stmt = $pdo->query("SELECT id, name, email, role FROM users ORDER BY name ASC");
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        // ── Assign SKU to user ──────────────────────────────
        case 'assign_sku':
            $sku_id_raw = $_POST['sku_id'] ?? '';
            $user_id = intval($_POST['user_id'] ?? 0);
            if (!$sku_id_raw || !$user_id) {
                echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
                break;
            }

            // Get user name
            $uname = $pdo->prepare("SELECT name FROM users WHERE id = ?");
            $uname->execute([$user_id]);
            $name = $uname->fetchColumn();

            if (strpos($sku_id_raw, 'bulk_') === 0) {
                // Bulk assignment
                $product_id = intval(str_replace('bulk_', '', $sku_id_raw));
                $quantity = floatval($_POST['quantity'] ?? 0);
                
                if ($quantity <= 0) {
                    echo json_encode(['success' => false, 'message' => 'Cantidad inválida para producto a granel']);
                    break;
                }

                $pdo->beginTransaction();
                
                // Deduct from warehouse
                $stmt = $pdo->prepare("UPDATE inventory_products SET total_quantity = total_quantity - ? WHERE id = ? AND total_quantity >= ?");
                $stmt->execute([$quantity, $product_id, $quantity]);
                
                if ($stmt->rowCount() === 0) {
                    $pdo->rollBack();
                    echo json_encode(['success' => false, 'message' => 'Stock insuficiente en almacén para la cantidad solicitada']);
                    break;
                }

                // Add to user stock
                $stmtStock = $pdo->prepare("INSERT INTO inventory_user_stock (user_id, product_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + ?");
                $stmtStock->execute([$user_id, $product_id, $quantity, $quantity]);

                $pdo->commit();
                echo json_encode(['success' => true, 'message' => "Asignado {$quantity} a {$name}", 'user_name' => $name]);
                break;
            }

            $sku_id = intval($sku_id_raw);
            $stmt = $pdo->prepare("UPDATE inventory_skus SET assigned_to = ? WHERE id = ?");
            $stmt->execute([$user_id, $sku_id]);
            echo json_encode(['success' => true, 'message' => "Asignado a {$name}", 'user_name' => $name]);
            break;

        // ── Unassign SKU ────────────────────────────────────
        case 'unassign_sku':
            $sku_id = intval($_POST['sku_id'] ?? 0);
            if (!$sku_id) {
                echo json_encode(['success' => false, 'message' => 'ID inválido']);
                break;
            }
            $stmt = $pdo->prepare("UPDATE inventory_skus SET assigned_to = NULL WHERE id = ?");
            $stmt->execute([$sku_id]);
            echo json_encode(['success' => true, 'message' => 'Asignación removida']);
            break;

        // ── Create entry (with photos) ──────────────────────
        case 'create_entry':
            $sku_id = intval($_POST['sku_id'] ?? 0);
            $user_id = intval($_SESSION['user_id'] ?? 0);
            $tipo = $_POST['tipo'] ?? 'entrada';
            $notas = trim($_POST['notas'] ?? '');
            $valid_tipos = ['entrada', 'salida', 'devolucion', 'reparacion'];

            if (!$sku_id || !in_array($tipo, $valid_tipos)) {
                echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
                break;
            }

            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO inventory_entries (sku_id, user_id, tipo, notas) VALUES (?, ?, ?, ?)");
            $stmt->execute([$sku_id, $user_id, $tipo, $notas]);
            $entry_id = $pdo->lastInsertId();

            // Movement logic: auto-update status and historia
            switch ($tipo) {
                case 'entrada':
                    $pdo->prepare("UPDATE inventory_skus SET status = 'disponible' WHERE id = ?")->execute([$sku_id]);
                    break;
                case 'salida':
                    $pdo->prepare("UPDATE inventory_skus SET status = 'en_transito', historia = 'en_transito' WHERE id = ?")->execute([$sku_id]);
                    break;
                case 'devolucion':
                    $pdo->prepare("UPDATE inventory_skus SET status = 'disponible', historia = 'devuelto' WHERE id = ?")->execute([$sku_id]);
                    break;
                case 'reparacion':
                    $pdo->prepare("UPDATE inventory_skus SET historia = 'malogrado' WHERE id = ?")->execute([$sku_id]);
                    break;
            }

            // Handle photo uploads
            $uploadDir = '../uploads/inventario/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

            if (!empty($_FILES['photos'])) {
                $photos = $_FILES['photos'];
                $count = is_array($photos['name']) ? count($photos['name']) : 0;
                for ($i = 0; $i < $count; $i++) {
                    if ($photos['error'][$i] === UPLOAD_ERR_OK) {
                        $ext = pathinfo($photos['name'][$i], PATHINFO_EXTENSION);
                        $filename = 'inv_' . $entry_id . '_' . uniqid() . '.' . $ext;
                        if (move_uploaded_file($photos['tmp_name'][$i], $uploadDir . $filename)) {
                            $ruta = 'uploads/inventario/' . $filename;
                            $pdo->prepare("INSERT INTO inventory_entry_photos (entry_id, ruta_archivo) VALUES (?, ?)")
                                ->execute([$entry_id, $ruta]);
                        }
                    }
                }
            }

            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Movimiento registrado', 'entry_id' => $entry_id]);
            break;

        // ── Update Historia ──────────────────────────────────
        case 'update_historia':
            $sku_id = intval($_POST['sku_id'] ?? 0);
            $historia = $_POST['historia'] ?? 'ninguno';
            $valid_hist = ['ninguno', 'devuelto', 'malogrado', 'antiguo', 'en_transito'];
            if (!$sku_id || !in_array($historia, $valid_hist)) {
                echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
                break;
            }
            $stmt = $pdo->prepare("UPDATE inventory_skus SET historia = ? WHERE id = ?");
            $stmt->execute([$historia, $sku_id]);
            echo json_encode(['success' => true, 'message' => 'Historia actualizada']);
            break;

        // ── Get SKU entries history ─────────────────────────
        case 'get_sku_entries':
            $sku_id = intval($_POST['sku_id'] ?? $_GET['sku_id'] ?? 0);
            if (!$sku_id) {
                echo json_encode(['success' => false, 'message' => 'ID inválido']);
                break;
            }
            $stmt = $pdo->prepare("SELECT e.*, u.name as user_name,
                                   (SELECT GROUP_CONCAT(ruta_archivo) FROM inventory_entry_photos WHERE entry_id = e.id) as photos
                                   FROM inventory_entries e
                                   JOIN users u ON e.user_id = u.id
                                   WHERE e.sku_id = ?
                                   ORDER BY e.created_at DESC");
            $stmt->execute([$sku_id]);
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Acción no válida']);
    }
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

/**
 * Genera un código aleatorio alfanumérico
 */
function generateRandomCode($length = 6) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Sin I,O,0,1 para evitar confusión
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $code;
}
