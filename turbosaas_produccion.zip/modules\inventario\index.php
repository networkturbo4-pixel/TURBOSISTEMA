<?php
require_once '../../config/db.php';
requireLogin();
requirePermission($pdo, 'inventario');
include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<link rel="stylesheet" href="<?php echo BASE_URL; ?>/modules/inventario/inventario.css?v=<?php echo time(); ?>">

<!-- Scanner Header -->
<div class="scanner-header">
    <div class="scanner-header-left">
        <div class="scanner-icon-box"><i class="ph ph-barcode"></i></div>
        <div>
            <h2 style="margin:0;font-size:1.15rem;font-weight:700;">Escáner de Inventario</h2>
            <p style="margin:0;font-size:0.82rem;color:rgba(255,255,255,0.7);">Escanea o escribe un código SKU para buscar</p>
        </div>
    </div>
    <div class="scanner-input-wrap">
        <i class="ph ph-magnifying-glass"></i>
        <input type="text" id="scannerInput" class="form-control" placeholder="Escanear o escribir código SKU..." autofocus>
        <button type="button" class="btn-scan-camera" id="btnScanCamera" title="Escanear con cámara"><i class="ph ph-camera"></i></button>
    </div>
</div>

<!-- Scanner Result -->
<div id="scannerResult" class="scanner-result" style="display:none;"></div>

<!-- Camera Modal -->
<div class="modal-overlay" id="cameraModal">
    <div class="modal-content" style="max-width:480px;">
        <div class="modal-header">
            <h3><i class="ph ph-camera"></i> Escáner de Cámara</h3>
            <button class="close-modal" onclick="closeCameraModal()">&times;</button>
        </div>
        <div class="modal-body" style="padding:0 16px 16px;">
            <div id="qr-reader" style="width:100%;border-radius:12px;overflow:hidden;"></div>
        </div>
    </div>
</div>

<!-- Metric Cards -->
<div class="row g-2 mb-4" id="metricCards">
    <div class="col-md-3 col-6">
        <div class="inv-metric-card">
            <div class="inv-metric-icon" style="background:rgba(99,102,241,0.1);"><i class="ph ph-cube" style="color:#6366f1;"></i></div>
            <div class="text-end"><p class="inv-metric-value" id="metricTotal" style="color:#6366f1;">0</p><h3 class="inv-metric-title">Total Unidades</h3></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="inv-metric-card">
            <div class="inv-metric-icon" style="background:rgba(16,185,129,0.1);"><i class="ph ph-check-circle" style="color:#10b981;"></i></div>
            <div class="text-end"><p class="inv-metric-value" id="metricDisponible" style="color:#10b981;">0</p><h3 class="inv-metric-title">Disponibles</h3></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="inv-metric-card">
            <div class="inv-metric-icon" style="background:rgba(59,130,246,0.1);"><i class="ph ph-arrow-circle-up" style="color:#3b82f6;"></i></div>
            <div class="text-end"><p class="inv-metric-value" id="metricInstalado" style="color:#3b82f6;">0</p><h3 class="inv-metric-title">Instalados</h3></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="inv-metric-card">
            <div class="inv-metric-icon" style="background:rgba(245,158,11,0.1);"><i class="ph ph-warning" style="color:#f59e0b;"></i></div>
            <div class="text-end"><p class="inv-metric-value" id="metricLowStock" style="color:#f59e0b;">0</p><h3 class="inv-metric-title">Por Agotarse</h3></div>
        </div>
    </div>
</div>

<!-- Tabs -->
<div class="inv-tabs-bar">
    <button class="inv-tab active" data-tab="productos"><i class="ph ph-package"></i> Productos</button>
    <button class="inv-tab" data-tab="stock"><i class="ph ph-chart-bar"></i> Control de Stock</button>
    <button class="inv-tab" data-tab="etiquetas"><i class="ph ph-tag"></i> Etiquetas</button>
</div>

<!-- Tab: Productos -->
<div class="inv-tab-pane active" id="tab-productos">
    <div class="inv-filter-row">
        <div class="inv-filter-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="text" class="form-control" id="searchProducts" placeholder="Buscar producto...">
        </div>
    </div>
    <div id="productsGrid" class="products-grid"></div>
    <div id="productsEmpty" class="empty-state" style="display:none;"><i class="ph ph-package" style="font-size:3rem;display:block;margin-bottom:12px;"></i>No hay productos registrados.</div>
</div>

<!-- Tab: Control de Stock -->
<div class="inv-tab-pane" id="tab-stock">
    <div class="inv-filter-row">
        <div class="inv-filter-search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="text" class="form-control" id="searchSku" placeholder="Buscar SKU...">
        </div>
        <select class="form-select inv-filter-select" id="filterProduct"><option value="">Todos los productos</option></select>
        <select class="form-select inv-filter-select" id="filterStatus">
            <option value="">Todos los estados</option>
            <option value="disponible">Disponible</option>
            <option value="instalado">Instalado</option>
            <option value="malogrado">Malogrado</option>
            <option value="reparado">Reparado</option>
            <option value="en_transito">En Tránsito</option>
        </select>
    </div>
    <div class="table-responsive">
        <table id="skuTable">
            <thead><tr><th>#</th><th>SKU</th><th>Producto</th><th>Categoría</th><th>Estado</th><th>Historia</th><th>Última Actividad</th><th>Instalado a</th><th>Asignado</th><th>Acción</th></tr></thead>
            <tbody id="skuTableBody"></tbody>
        </table>
    </div>
    <div id="skuEmpty" class="empty-state" style="display:none;">No hay SKUs registrados.</div>
</div>

<!-- Tab: Etiquetas -->
<div class="inv-tab-pane" id="tab-etiquetas">
    <div class="inv-filter-row">
        <select class="form-select inv-filter-select" id="labelProduct" style="flex:1;max-width:300px;"><option value="">Seleccionar producto...</option></select>
        <select class="form-select inv-filter-select" id="labelType">
            <option value="barcode">Código de Barras</option>
            <option value="qr">Código QR</option>
        </select>
        <button class="btn btn-primary" id="btnGenLabels"><i class="ph ph-printer"></i> Generar</button>
        <button class="btn btn-secondary" id="btnPrint" style="display:none;" onclick="window.print()"><i class="ph ph-printer"></i> Imprimir</button>
    </div>
    <div id="labelPreview" class="label-preview-container"></div>
</div>

<!-- FAB -->
<button class="fab" id="btnNewProduct" title="Nuevo Producto"><i class="ph ph-plus"></i></button>

<!-- Modal: New Product -->
<div class="modal-overlay" id="newProductModal">
    <div class="modal-content" style="max-width:780px;">
        <div class="modal-header">
            <h3><i class="ph ph-package"></i> Nuevo Producto</h3>
            <button class="close-modal" onclick="closeProductModal()">&times;</button>
        </div>
        <div class="modal-body">
            <!-- Row 1: Name, Category -->
            <div class="inv-form-row">
                <div class="inv-form-field" style="flex:2;">
                    <label class="form-label">Nombre del Producto</label>
                    <input type="text" class="form-control" id="prodName" required placeholder="Ej: Router TP-Link">
                </div>
                <div class="inv-form-field">
                    <label class="form-label">Categoría</label>
                    <div style="display:flex;gap:6px;">
                        <select class="form-select" id="prodCategory" style="flex:1;"><option value="">Sin categoría</option></select>
                        <button type="button" class="btn btn-secondary" onclick="promptNewCategory()" title="Nueva categoría" style="padding:10px;flex-shrink:0;"><i class="ph ph-plus"></i></button>
                    </div>
                </div>
            </div>

            <!-- Row 2: Stock minimo, Stock critico, Descripcion -->
            <div class="inv-form-row">
                <div class="inv-form-field" style="flex:0.7;">
                    <label class="form-label">Stock Mínimo</label>
                    <input type="number" class="form-control" id="prodStockMin" min="0" value="10" placeholder="10">
                </div>
                <div class="inv-form-field" style="flex:0.7;">
                    <label class="form-label">Stock Crítico</label>
                    <input type="number" class="form-control" id="prodStockCrit" min="0" value="3" placeholder="3">
                </div>
                <div class="inv-form-field" style="flex:2;">
                    <label class="form-label">Descripción</label>
                    <input type="text" class="form-control" id="prodDesc" placeholder="Descripción breve del producto...">
                </div>
            </div>

            <!-- Row 2.5: Bulk -->
            <div class="inv-form-row align-items-end" style="background:var(--bg-color); padding:12px; border-radius:8px; margin-bottom:16px; border: 1px solid var(--border-color);">
                <div class="inv-form-field">
                    <div class="form-check" style="margin-bottom:0;">
                        <input class="form-check-input" type="checkbox" id="prodIsBulk" onchange="toggleBulkMode(this.checked)">
                        <label class="form-check-label" for="prodIsBulk" style="font-weight:700;">Es material a granel (No usa SKUs individuales)</label>
                    </div>
                    <small style="color:var(--text-muted);display:block;margin-top:4px;">Selecciona si el producto se maneja por metros, litros, kilos, etc.</small>
                </div>
                <div class="inv-form-field" id="prodUnitWrap" style="display:none; flex:0.4;">
                    <label class="form-label">Unidad</label>
                    <select class="form-select" id="prodUnitType">
                        <option value="Unidades">Unidades</option>
                        <option value="Metros (m)">Metros (m)</option>
                        <option value="Centímetros (cm)">Centímetros (cm)</option>
                        <option value="Milímetros (mm)">Milímetros (mm)</option>
                        <option value="Kilómetros (km)">Kilómetros (km)</option>
                        <option value="Gramos (g)">Gramos (g)</option>
                        <option value="Kilogramos (kg)">Kilogramos (kg)</option>
                        <option value="Litros (L)">Litros (L)</option>
                    </select>
                </div>
                <div class="inv-form-field" id="prodMasterSkuWrap" style="display:none; flex:0.6;">
                    <label class="form-label">SKU Maestro (Opcional)</label>
                    <input type="text" class="form-control" id="prodMasterSku" placeholder="Ej: CABLE-UTP-01">
                </div>
            </div>

            <!-- Row 3: Custom Columns -->
            <div style="margin-bottom:16px;">
                <label class="form-label"><i class="ph ph-columns"></i> Columnas Personalizadas (por SKU)</label>
                <div class="inv-custom-cols-wrap">
                    <div id="customColsList" class="inv-custom-cols-list"></div>
                    <div style="display:flex;gap:6px;">
                        <input type="text" class="form-control" id="newColName" placeholder="Ej: Ubicación, Serial, Nota..." style="flex:1;">
                        <button type="button" class="btn btn-secondary" onclick="addCustomColumn()" style="flex-shrink:0;"><i class="ph ph-plus"></i> Agregar</button>
                    </div>
                </div>
            </div>

            <!-- Row 4: SKU Generation Mode -->
            <div style="margin-bottom:14px;">
                <label class="form-label"><i class="ph ph-list-numbers"></i> SKUs del Producto</label>
                <div class="inv-mode-toggle">
                    <button type="button" class="inv-mode-btn active" id="modeAuto" onclick="setSkuMode('auto')"><i class="ph ph-lightning"></i> Automático</button>
                    <button type="button" class="inv-mode-btn" id="modeManual" onclick="setSkuMode('manual')"><i class="ph ph-pencil-line"></i> Manual</button>
                </div>
            </div>

            <!-- Auto mode: Quantity input -->
            <div id="autoModeWrap" class="inv-form-row" style="margin-bottom:14px;">
                <div class="inv-form-field" style="flex:0.5;">
                    <label class="form-label">Cantidad a generar</label>
                    <input type="number" class="form-control" id="prodQty" min="1" value="1" placeholder="500">
                </div>
                <div class="inv-form-field" style="flex:1;display:flex;align-items:flex-end;">
                    <button type="button" class="btn btn-primary" id="btnGenerateSkus" onclick="generateAutoSkus()" style="height:44px;"><i class="ph ph-lightning"></i> Generar SKUs</button>
                </div>
            </div>

            <!-- Manual mode: Add button (hidden by default) -->
            <div id="manualModeWrap" style="display:none;margin-bottom:14px;">
                <button type="button" class="btn btn-primary" onclick="addManualSkuRow()"><i class="ph ph-plus-circle"></i> Agregar Fila</button>
            </div>

            <!-- SKU Preview Table -->
            <div id="skuPreviewWrap" style="display:none;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                    <h4 style="font-size:0.95rem;font-weight:700;margin:0;" id="skuPreviewTitle">SKUs: 0</h4>
                    <span id="skuPreviewCount" style="font-size:0.8rem;color:var(--text-muted);"></span>
                </div>
                <div class="table-responsive" style="max-height:300px;overflow-y:auto;border:1px solid var(--border-color);border-radius:10px;">
                    <table>
                        <thead id="skuPreviewHead"><tr><th>#</th><th>SKU Code</th><th>Estado</th><th></th></tr></thead>
                        <tbody id="skuPreviewBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeProductModal()">Cancelar</button>
            <button class="btn btn-primary" id="btnSaveProduct"><i class="ph ph-floppy-disk"></i> Guardar Producto</button>
        </div>
    </div>
</div>

<!-- Modal: Scan Picker (multi-detect, user picks one) -->
<div class="modal-overlay" id="scanPickerModal" style="z-index:1050;">
    <div class="modal-content" style="max-width:500px;">
        <div class="modal-header">
            <h3><i class="ph ph-qr-code"></i> Escanear Código</h3>
            <button class="close-modal" onclick="closeScanPicker()">&times;</button>
        </div>
        <div class="modal-body">
            <div id="scanPickerReader" style="width:100%;border-radius:12px;overflow:hidden;margin-bottom:16px;"></div>
            <div id="scanPickerStatus" style="text-align:center;color:var(--text-muted);font-size:0.85rem;margin-bottom:12px;">
                <i class="ph ph-camera"></i> Apunta la cámara al código...
            </div>
            <div id="scanPickerResults" style="display:none;">
                <label class="form-label" style="font-size:0.85rem;">Códigos detectados — selecciona uno:</label>
                <div id="scanPickerList" class="scan-picker-list"></div>
            </div>
            <div style="margin-top:12px;">
                <label class="form-label" style="font-size:0.85rem;">O escribe manualmente:</label>
                <div style="display:flex;gap:8px;">
                    <input type="text" class="form-control" id="scanPickerManual" placeholder="Escribir código...">
                    <button class="btn btn-primary" onclick="selectManualScan()" style="flex-shrink:0;"><i class="ph ph-check"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal: SKU Detail (2 tabs) -->
<div class="modal-overlay" id="skuDetailModal">
    <div class="modal-content" style="max-width:700px;">
        <div class="modal-header">
            <h3><i class="ph ph-package"></i> <span id="skuDetailTitle">Detalle SKU</span></h3>
            <button class="close-modal" onclick="closeSkuDetail()">&times;</button>
        </div>
        <div class="modal-body" style="padding:0;">
            <!-- Tabs -->
            <div class="inv-tabs-bar" style="margin-bottom:0;border-radius:0;border:none;border-bottom:1px solid var(--border-color);">
                <button class="inv-tab active" data-dtab="edit" onclick="switchDetailTab('edit')"><i class="ph ph-pencil-simple"></i> Editar</button>
                <button class="inv-tab" data-dtab="assign" onclick="switchDetailTab('assign')"><i class="ph ph-user"></i> Asignar</button>
            </div>

            <!-- Tab: Editar -->
            <div class="sdt-pane active" id="dtab-edit" style="padding:20px;">
                <div class="sku-detail-info" id="skuEditInfo"></div>
                <div style="margin-top:16px;">
                    <label class="form-label">Cambiar Estado</label>
                    <select class="form-select" id="skuDetailStatus" onchange="updateSkuDetailStatus()">
                        <option value="disponible">Disponible</option>
                        <option value="instalado">Instalado</option>
                        <option value="malogrado">Malogrado</option>
                        <option value="reparado">Reparado</option>
                        <option value="en_transito">En Tránsito</option>
                    </select>
                </div>
            </div>

            <!-- Tab: Asignar + Movimiento -->
            <div class="sdt-pane" id="dtab-assign" style="padding:20px;">
                <div id="skuAssignCurrent" style="margin-bottom:16px;"></div>
                <label class="form-label">Asignar a usuario</label>
                <select class="form-select" id="skuAssignUser">
                    <option value="">Seleccionar usuario...</option>
                </select>
                <div style="display:flex;gap:8px;margin-top:12px;margin-bottom:20px;">
                    <button class="btn btn-primary" onclick="assignSkuToUser()" style="flex:1;"><i class="ph ph-user-plus"></i> Asignar</button>
                    <button class="btn btn-secondary" onclick="unassignSku()" style="flex:1;"><i class="ph ph-user-minus"></i> Desasignar</button>
                </div>

                <hr style="border-color:var(--border-color);margin:16px 0;">

                <!-- Movimiento -->
                <h4 style="font-size:0.9rem;font-weight:700;margin-bottom:10px;"><i class="ph ph-swap"></i> Registrar Movimiento</h4>
                <div style="margin-bottom:12px;">
                    <label class="form-label">Tipo de Movimiento</label>
                    <select class="form-select" id="entryType">
                        <option value="entrada">📥 Entrada</option>
                        <option value="salida">📤 Salida</option>
                        <option value="devolucion">🔄 Devolución</option>
                        <option value="reparacion">🔧 Reparación</option>
                    </select>
                </div>
                <div style="margin-bottom:12px;">
                    <label class="form-label">Notas</label>
                    <textarea class="form-control" id="entryNotas" rows="2" placeholder="Descripción del movimiento..."></textarea>
                </div>
                <div style="margin-bottom:12px;">
                    <label class="form-label"><i class="ph ph-camera"></i> Fotos de Evidencia</label>
                    <div class="inv-photo-buttons">
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('entryPhotosCamera').click()" style="flex:1;"><i class="ph ph-camera"></i> Tomar Foto</button>
                        <button type="button" class="btn btn-secondary" onclick="document.getElementById('entryPhotosGallery').click()" style="flex:1;"><i class="ph ph-images"></i> Galería</button>
                    </div>
                    <div id="photoPreviewList" class="inv-photo-previews"></div>
                </div>
                <!-- Hidden file inputs -->
                <input type="file" id="entryPhotosCamera" class="no-dropzone" accept="image/*" capture="environment" onchange="previewEntryPhotos(this)" style="position:absolute;width:0;height:0;overflow:hidden;opacity:0;pointer-events:none;">
                <input type="file" id="entryPhotosGallery" class="no-dropzone" multiple accept="image/*" onchange="previewEntryPhotos(this)" style="position:absolute;width:0;height:0;overflow:hidden;opacity:0;pointer-events:none;">

                <div style="margin-top:20px;">
                    <h4 style="font-size:0.9rem;font-weight:700;margin-bottom:10px;"><i class="ph ph-clock-counter-clockwise"></i> Historial</h4>
                    <div id="entryHistoryList" class="inv-entry-history" style="max-height:150px; overflow-y:auto; margin-bottom: 20px;"></div>
                </div>

                <div style="position:sticky; bottom:-20px; background:var(--bg-color); padding-top:10px; margin-left:-20px; margin-right:-20px; padding-left:20px; padding-right:20px; border-top:1px solid var(--border-color); z-index:10;">
                    <button class="btn btn-primary" onclick="submitEntry()" style="width:100%;"><i class="ph ph-floppy-disk"></i> Guardar Movimiento</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Libraries -->
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
<script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="<?php echo BASE_URL; ?>/modules/inventario/inventario.js?v=<?php echo time(); ?>"></script>

<?php include '../../includes/footer.php'; ?>
