/* INVENTARIO MODULE — JavaScript */
(function() {
    const BASE = document.querySelector('script[src*="inventario.js"]').src.split('/modules/')[0];
    let html5QrCode = null;
    let customColumns = [];
    let previewCustomData = []; // [{col: value, ...}, ...] per SKU row
    let previewSkuCodes = [];
    let scanPickerCallback = null;
    let scanPickerScanner = null;
    let scanPickerDetected = [];
    let skuMode = 'auto'; // 'auto' or 'manual'

    document.addEventListener('DOMContentLoaded', () => {
        loadMetrics(); loadProducts(); loadCategories();
        initTabs(); initScanner(); initProductModal(); initStockTab(); initLabelsTab();
    });

    // ── Tabs ──
    function initTabs() {
        document.querySelectorAll('.inv-tab').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.inv-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.inv-tab-pane').forEach(p => p.classList.remove('active'));
                btn.classList.add('active');
                document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
                if (btn.dataset.tab === 'stock') loadAllSkus();
                if (btn.dataset.tab === 'etiquetas') populateLabelProducts();
            });
        });
    }

    // ── Metrics ──
    async function loadMetrics() {
        try {
            const fd = new FormData(); fd.append('action', 'get_stock_summary');
            const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
            if (res.success) {
                document.getElementById('metricTotal').textContent = res.data.total;
                document.getElementById('metricDisponible').textContent = res.data.disponible;
                document.getElementById('metricInstalado').textContent = res.data.instalado;
                document.getElementById('metricLowStock').textContent = res.data.low_stock;
            }
        } catch (e) { console.error(e); }
    }

    // ── Scanner ──
    function initScanner() {
        const input = document.getElementById('scannerInput');
        let t;
        input.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { if (input.value.trim().length >= 3) searchSku(input.value.trim()); }, 400); });
        input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); searchSku(input.value.trim()); } });
        document.getElementById('btnScanCamera').addEventListener('click', openCameraModal);
    }

    async function searchSku(code) {
        const r = document.getElementById('scannerResult');
        if (!code) { r.style.display = 'none'; return; }
        try {
            const fd = new FormData(); fd.append('action', 'search_sku'); fd.append('code', code);
            const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(x => x.json());
            if (res.success) {
                const d = res.data;
                const c = { disponible:'#10b981', instalado:'#3b82f6', malogrado:'#ef4444', reparado:'#f59e0b' };
                const ic = { disponible:'ph-check-circle', instalado:'ph-arrow-circle-up', malogrado:'ph-x-circle', reparado:'ph-wrench' };
                r.innerHTML = `<div class="sr-icon" style="background:${c[d.status]}20;color:${c[d.status]};"><i class="ph ${ic[d.status]}"></i></div><div class="sr-info"><h4>${d.sku_code} — ${d.product_name}</h4><p>Categoría: ${d.category_name||'Sin categoría'} · <span class="status-badge status-${d.status}">${d.status.toUpperCase()}</span></p></div>`;
                r.style.display = 'none';
                // Open detail modal
                openSkuDetailModal(d);
            } else {
                r.innerHTML = `<div class="sr-icon" style="background:#fef2f2;color:#ef4444;"><i class="ph ph-x-circle"></i></div><div class="sr-info"><h4>No encontrado</h4><p>El código "${esc(code)}" no existe.</p></div>`;
                r.style.display = 'flex';
            }
        } catch (e) { r.style.display = 'none'; }
    }

    // ── Camera ──
    window.openCameraModal = function() { document.getElementById('cameraModal').classList.add('active'); setTimeout(startCamera, 300); };
    window.closeCameraModal = function() { document.getElementById('cameraModal').classList.remove('active'); stopCamera(); };
    function startCamera() {
        if (html5QrCode) stopCamera();
        html5QrCode = new Html5Qrcode("qr-reader");
        html5QrCode.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 150 } },
            (decoded) => { document.getElementById('scannerInput').value = decoded; searchSku(decoded); closeCameraModal(); if (window.showToast) window.showToast('Código escaneado: ' + decoded, 'success'); },
            () => {}
        ).catch(err => console.warn(err));
    }
    function stopCamera() { if (html5QrCode) { html5QrCode.stop().catch(()=>{}); html5QrCode.clear(); html5QrCode = null; } }

    // ── Products ──
    async function loadProducts() {
        try {
            const fd = new FormData(); fd.append('action', 'list_products');
            const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
            const grid = document.getElementById('productsGrid');
            const empty = document.getElementById('productsEmpty');
            if (res.success && res.data.length > 0) {
                grid.style.display = 'grid'; empty.style.display = 'none';
                grid.innerHTML = res.data.map(p => `
                    <div class="product-card" data-name="${(p.name||'').toLowerCase()}">
                        <div class="product-card-header"><h3>${esc(p.name)}</h3><span class="cat-badge">${esc(p.category_name||'Sin cat.')}</span></div>
                        <div class="product-stats">
                            ${p.is_bulk == 1 
                                ? `<div class="product-stat"><span class="stat-num" style="color:#10b981;">${p.total_quantity}</span><span class="stat-label">${esc(p.unit_type||'Und')}</span></div>`
                                : `<div class="product-stat"><span class="stat-num" style="color:#6366f1;">${p.total_quantity}</span><span class="stat-label">Total</span></div>
                                   <div class="product-stat"><span class="stat-num" style="color:#10b981;">${p.qty_disponible}</span><span class="stat-label">Disp.</span></div>
                                   <div class="product-stat"><span class="stat-num" style="color:#3b82f6;">${p.qty_instalado}</span><span class="stat-label">Inst.</span></div>
                                   <div class="product-stat"><span class="stat-num" style="color:#ef4444;">${p.qty_malogrado}</span><span class="stat-label">Malo.</span></div>`
                            }
                        </div>
                        <div class="product-actions">
                            ${p.is_bulk == 1 ? '' : `<button class="btn-view-skus" onclick="viewProductSkus(${p.id})"><i class="ph ph-list-bullets"></i> Ver SKUs</button>`}
                            <button class="btn-delete-prod" onclick="deleteProduct(${p.id})"><i class="ph ph-trash"></i> Eliminar</button>
                        </div>
                    </div>`).join('');
            } else { grid.style.display = 'none'; empty.style.display = 'block'; }
        } catch (e) { console.error(e); }
    }

    document.addEventListener('DOMContentLoaded', () => {
        const si = document.getElementById('searchProducts');
        if (si) si.addEventListener('input', () => { const q = si.value.toLowerCase(); document.querySelectorAll('.product-card').forEach(c => { c.style.display = c.dataset.name.includes(q) ? '' : 'none'; }); });
    });

    window.viewProductSkus = function(id) {
        document.querySelectorAll('.inv-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.inv-tab-pane').forEach(p => p.classList.remove('active'));
        document.querySelector('[data-tab="stock"]').classList.add('active');
        document.getElementById('tab-stock').classList.add('active');
        document.getElementById('filterProduct').value = id;
        loadAllSkus();
    };

    window.deleteProduct = async function(id) {
        if (!confirm('¿Eliminar este producto y todos sus SKUs?')) return;
        const fd = new FormData(); fd.append('action', 'delete_product'); fd.append('id', id);
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) { if (window.showToast) window.showToast(res.message, 'success'); loadProducts(); loadMetrics(); }
        else { if (window.showToast) window.showToast(res.message, 'error'); }
    };

    // ── Categories ──
    async function loadCategories() {
        const fd = new FormData(); fd.append('action', 'list_categories');
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) {
            const sel = document.getElementById('prodCategory');
            sel.innerHTML = '<option value="">Sin categoría</option>';
            res.data.forEach(c => { sel.innerHTML += `<option value="${c.id}">${esc(c.name)}</option>`; });
        }
    }
    window.promptNewCategory = async function() {
        const name = prompt('Nombre de la nueva categoría:');
        if (!name || !name.trim()) return;
        const fd = new FormData(); fd.append('action', 'create_category'); fd.append('name', name.trim());
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) { await loadCategories(); document.getElementById('prodCategory').value = res.id; if (window.showToast) window.showToast('Categoría creada', 'success'); }
    };

    // ── Custom Columns ──
    window.addCustomColumn = function() {
        const input = document.getElementById('newColName');
        const name = input.value.trim();
        if (!name) return;
        if (customColumns.includes(name)) { if (window.showToast) window.showToast('Esa columna ya existe', 'error'); return; }
        customColumns.push(name);
        input.value = '';
        renderCustomCols();
        if (previewSkuCodes.length > 0) renderSkuTable();
    };
    window.removeCustomColumn = function(idx) {
        customColumns.splice(idx, 1);
        renderCustomCols();
        if (previewSkuCodes.length > 0) renderSkuTable();
    };
    function renderCustomCols() {
        const list = document.getElementById('customColsList');
        list.innerHTML = customColumns.map((c, i) => `<span class="inv-col-pill">${esc(c)} <i class="ph ph-x" onclick="removeCustomColumn(${i})"></i></span>`).join('');
    }

    // ── Product Modal ──
    function initProductModal() {
        document.getElementById('btnNewProduct').addEventListener('click', () => {
            document.getElementById('newProductModal').classList.add('active');
            document.getElementById('prodName').value = '';
            document.getElementById('prodQty').value = 1;
            document.getElementById('prodDesc').value = '';
            document.getElementById('prodStockMin').value = 10;
            document.getElementById('prodStockCrit').value = 3;
            document.getElementById('skuPreviewWrap').style.display = 'none';
            previewCustomData = [];
            previewSkuCodes = [];
            customColumns = [];
            skuMode = 'auto';
            renderCustomCols();
            setSkuMode('auto');
            loadCategories();
        });

        document.getElementById('btnSaveProduct').addEventListener('click', async () => {
            const name = document.getElementById('prodName').value.trim();
            const category_id = document.getElementById('prodCategory').value;
            const quantity = previewSkuCodes.length;
            const description = document.getElementById('prodDesc').value.trim();
            const stock_minimo = parseInt(document.getElementById('prodStockMin').value) || 0;
            const stock_critico = parseInt(document.getElementById('prodStockCrit').value) || 0;
            const is_bulk = document.getElementById('prodIsBulk').checked ? 1 : 0;
            const unit_type = document.getElementById('prodUnitType').value;
            const master_sku = document.getElementById('prodMasterSku').value.trim();

            if (!name) { if (window.showToast) window.showToast('El nombre es requerido', 'error'); return; }
            if (!is_bulk && quantity < 1) { if (window.showToast) window.showToast('Agrega al menos 1 SKU', 'error'); return; }

            const btn = document.getElementById('btnSaveProduct');
            btn.disabled = true; btn.innerHTML = '<i class="ph ph-spinner"></i> Guardando...';

            const fd = new FormData();
            fd.append('action', 'create_product');
            fd.append('name', name);
            fd.append('category_id', category_id);
            fd.append('quantity', is_bulk ? (parseInt(document.getElementById('prodQty').value) || 0) : quantity);
            fd.append('description', description);
            fd.append('stock_minimo', stock_minimo);
            fd.append('stock_critico', stock_critico);
            fd.append('is_bulk', is_bulk);
            fd.append('unit_type', unit_type);
            fd.append('master_sku', master_sku);
            fd.append('custom_columns', JSON.stringify(customColumns));
            fd.append('preview_custom_data', JSON.stringify(previewCustomData));

            try {
                const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
                if (res.success) { if (window.showToast) window.showToast(res.message, 'success'); closeProductModal(); loadProducts(); loadMetrics(); }
                else { if (window.showToast) window.showToast(res.message, 'error'); }
            } catch (e) { if (window.showToast) window.showToast('Error del servidor', 'error'); }
            btn.disabled = false; btn.innerHTML = '<i class="ph ph-floppy-disk"></i> Guardar Producto';
        });
    }

    // ── Bulk Mode Toggle ──
    window.toggleBulkMode = function(isBulk) {
        document.getElementById('prodUnitWrap').style.display = isBulk ? 'block' : 'none';
        document.getElementById('prodMasterSkuWrap').style.display = isBulk ? 'block' : 'none';
        
        // Hide SKU related sections
        const skuModeToggle = document.querySelector('.inv-mode-toggle').parentElement;
        const customCols = document.querySelector('.inv-custom-cols-wrap').parentElement;
        const autoModeWrap = document.getElementById('autoModeWrap');
        const manualModeWrap = document.getElementById('manualModeWrap');
        const previewWrap = document.getElementById('skuPreviewWrap');

        if (isBulk) {
            skuModeToggle.style.display = 'none';
            customCols.style.display = 'none';
            manualModeWrap.style.display = 'none';
            previewWrap.style.display = 'none';
            // Show only the quantity input from auto mode, hide the "Generate SKUs" button
            autoModeWrap.style.display = 'flex';
            document.getElementById('btnGenerateSkus').style.display = 'none';
            document.getElementById('prodQty').parentElement.querySelector('label').textContent = 'Cantidad Inicial (Stock)';
        } else {
            skuModeToggle.style.display = 'block';
            customCols.style.display = 'block';
            document.getElementById('btnGenerateSkus').style.display = 'inline-flex';
            document.getElementById('prodQty').parentElement.querySelector('label').textContent = 'Cantidad a generar';
            setSkuMode(skuMode);
        }
    };

    // ── Mode Toggle ──
    window.setSkuMode = function(mode) {
        skuMode = mode;
        if (document.getElementById('prodIsBulk').checked) return;
        document.getElementById('modeAuto').classList.toggle('active', mode === 'auto');
        document.getElementById('modeManual').classList.toggle('active', mode === 'manual');
        document.getElementById('autoModeWrap').style.display = mode === 'auto' ? 'flex' : 'none';
        document.getElementById('manualModeWrap').style.display = mode === 'manual' ? 'block' : 'none';
        if (mode === 'manual') {
            // If switching to manual and no rows yet, show table
            if (previewSkuCodes.length === 0) {
                document.getElementById('skuPreviewWrap').style.display = 'none';
            } else {
                renderSkuTable();
            }
        }
    };

    // ── Auto Mode: Generate ──
    window.generateAutoSkus = function() {
        const qty = parseInt(document.getElementById('prodQty').value) || 0;
        if (qty < 1 || qty > 2000) { if (window.showToast) window.showToast('Cantidad entre 1 y 2000', 'error'); return; }
        previewSkuCodes = [];
        previewCustomData = [];
        for (let i = 0; i < qty; i++) {
            previewSkuCodes.push('TRB-' + randomCode(6));
            const obj = {}; customColumns.forEach(c => obj[c] = ''); previewCustomData.push(obj);
        }
        renderSkuTable();
    };

    // ── Manual Mode: Add Row (empty) ──
    window.addManualSkuRow = function() {
        previewSkuCodes.push('');
        const obj = {}; customColumns.forEach(c => obj[c] = ''); previewCustomData.push(obj);
        renderSkuTable();
        // Auto-focus the new empty SKU cell
        setTimeout(() => {
            const rows = document.querySelectorAll('#skuPreviewBody tr');
            const lastRow = rows[rows.length - 1];
            if (lastRow) {
                const skuCell = lastRow.querySelector('.inv-editable-sku');
                if (skuCell) skuCell.click();
            }
        }, 50);
    };

    // ── Delete Row ──
    window.deleteSkuRow = function(idx) {
        previewSkuCodes.splice(idx, 1);
        previewCustomData.splice(idx, 1);
        renderSkuTable();
    };

    // ── Edit SKU Code inline (preview table) ──
    window.editPreviewSkuCode = function(idx, el) {
        const current = previewSkuCodes[idx] || '';
        const input = document.createElement('input');
        input.className = 'inv-editable-input';
        input.value = current;
        input.placeholder = 'TRB-XXXXXX';
        input.style.maxWidth = '150px';
        input.style.fontWeight = '700';
        input.style.fontFamily = 'monospace';
        el.innerHTML = '';
        el.appendChild(input);
        input.focus();
        const save = () => {
            const val = input.value.trim();
            previewSkuCodes[idx] = val;
            if (val) {
                el.innerHTML = `<code style="font-weight:700;font-size:0.9rem;">${esc(val)}</code>`;
            } else {
                el.innerHTML = '<em style="color:var(--text-muted);font-size:0.85rem;">Clic para escribir...</em>';
            }
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); if (e.key === 'Escape') { input.value = current; input.blur(); } });
    };

    // ── Render SKU Table ──
    function renderSkuTable() {
        const wrap = document.getElementById('skuPreviewWrap');
        const body = document.getElementById('skuPreviewBody');
        const head = document.getElementById('skuPreviewHead');
        const title = document.getElementById('skuPreviewTitle');
        const count = document.getElementById('skuPreviewCount');
        const qty = previewSkuCodes.length;

        if (qty === 0) { wrap.style.display = 'none'; return; }
        wrap.style.display = 'block';
        title.textContent = `SKUs: ${qty}`;
        count.textContent = skuMode === 'manual' ? 'Modo manual' : 'Modo automático';

        // Ensure each row has all columns
        previewCustomData.forEach(obj => {
            customColumns.forEach(c => { if (!(c in obj)) obj[c] = ''; });
        });

        // Header
        let headHtml = '<tr><th>#</th><th>SKU Code</th><th>Estado</th>';
        customColumns.forEach(c => { headHtml += `<th>${esc(c)}</th>`; });
        headHtml += '<th></th></tr>';
        head.innerHTML = headHtml;

        // Rows
        let rowsHtml = '';
        for (let i = 0; i < qty; i++) {
            const skuVal = previewSkuCodes[i];
            const skuDisplay = skuVal
                ? `<code style="font-weight:700;font-size:0.9rem;">${esc(skuVal)}</code>`
                : '<em style="color:var(--text-muted);font-size:0.85rem;">Clic para escribir...</em>';

            rowsHtml += `<tr>`;
            rowsHtml += `<td data-label="#">${i+1}</td>`;
            rowsHtml += `<td data-label="SKU Code"><span class="inv-editable inv-editable-sku" onclick="editPreviewSkuCode(${i},this)" title="Clic para editar">${skuDisplay}</span></td>`;
            rowsHtml += `<td data-label="Estado"><span class="status-badge status-disponible">DISPONIBLE</span></td>`;
            customColumns.forEach(col => {
                const val = previewCustomData[i][col] || '';
                const display = val ? esc(val) : '<em style="color:var(--text-muted)">—</em>';
                rowsHtml += `<td data-label="${esc(col)}"><div class="inv-cell-scannable">`;
                rowsHtml += `<span class="inv-editable" onclick="editPreviewCell(${i},'${esc(col)}',this)" title="Clic para editar">${display}</span>`;
                rowsHtml += `<button type="button" class="btn-scan-cell" onclick="openScanForCell(${i},'${esc(col)}')" title="Escanear"><i class="ph ph-qr-code"></i></button>`;
                rowsHtml += `</div></td>`;
            });
            rowsHtml += `<td data-label=""><button type="button" class="btn-delete-row" onclick="deleteSkuRow(${i})" title="Eliminar"><i class="ph ph-trash"></i></button></td></tr>`;
        }
        body.innerHTML = rowsHtml;
    }

    // ── Edit preview cell inline ──
    window.editPreviewCell = function(rowIdx, col, el) {
        const current = previewCustomData[rowIdx]?.[col] || '';
        const input = document.createElement('input');
        input.className = 'inv-editable-input';
        input.value = current;
        input.style.maxWidth = '120px';
        el.innerHTML = '';
        el.appendChild(input);
        input.focus();
        const save = () => {
            const val = input.value.trim();
            previewCustomData[rowIdx][col] = val;
            el.innerHTML = val ? esc(val) : '<em style="color:var(--text-muted)">—</em>';
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); if (e.key === 'Escape') { input.value = current; input.blur(); } });
    };

    // ── Scan Picker for Preview Cells ──
    window.openScanForCell = function(rowIdx, col) {
        scanPickerDetected = [];
        scanPickerCallback = (value) => {
            previewCustomData[rowIdx][col] = value;
            renderSkuTable();
            if (window.showToast) window.showToast('Código asignado: ' + value, 'success');
        };
        document.getElementById('scanPickerModal').classList.add('active');
        document.getElementById('scanPickerManual').value = '';
        document.getElementById('scanPickerResults').style.display = 'none';
        document.getElementById('scanPickerList').innerHTML = '';
        document.getElementById('scanPickerStatus').innerHTML = '<i class="ph ph-camera"></i> Apunta la cámara al código...';
        setTimeout(startScanPicker, 300);
    };

    window.closeScanPicker = function() {
        document.getElementById('scanPickerModal').classList.remove('active');
        stopScanPicker();
        scanPickerCallback = null;
    };

    window.selectManualScan = function() {
        const val = document.getElementById('scanPickerManual').value.trim();
        if (!val) return;
        if (scanPickerCallback) scanPickerCallback(val);
        closeScanPicker();
    };

    window.selectDetectedCode = function(code) {
        if (scanPickerCallback) scanPickerCallback(code);
        closeScanPicker();
    };

    function startScanPicker() {
        if (scanPickerScanner) stopScanPicker();
        scanPickerScanner = new Html5Qrcode('scanPickerReader');
        scanPickerScanner.start(
            { facingMode: 'environment' },
            { fps: 10, qrbox: { width: 250, height: 150 } },
            (decoded) => {
                if (!scanPickerDetected.includes(decoded)) {
                    scanPickerDetected.push(decoded);
                    renderScanPickerList();
                    // Vibrate feedback
                    if (navigator.vibrate) navigator.vibrate(100);
                }
            },
            () => {}
        ).catch(err => {
            console.warn('Scan picker camera error:', err);
            document.getElementById('scanPickerStatus').innerHTML = '<i class="ph ph-warning"></i> No se pudo acceder a la cámara. Escribe el código manualmente.';
        });
    }

    function stopScanPicker() {
        if (scanPickerScanner) {
            scanPickerScanner.stop().catch(() => {});
            scanPickerScanner.clear();
            scanPickerScanner = null;
        }
    }

    function renderScanPickerList() {
        const container = document.getElementById('scanPickerResults');
        const list = document.getElementById('scanPickerList');
        const status = document.getElementById('scanPickerStatus');
        if (scanPickerDetected.length > 0) {
            container.style.display = 'block';
            status.innerHTML = `<i class="ph ph-check-circle" style="color:#10b981;"></i> ${scanPickerDetected.length} código(s) detectado(s)`;
            list.innerHTML = scanPickerDetected.map(code =>
                `<div class="scan-picker-item" onclick="selectDetectedCode('${esc(code)}')">`
                + `<code>${esc(code)}</code>`
                + `<button class="pick-btn">Usar este</button>`
                + `</div>`
            ).join('');
        }
    }

    window.closeProductModal = function() { document.getElementById('newProductModal').classList.remove('active'); };

    // ── Stock Control Tab ──
    function initStockTab() {
        document.getElementById('filterStatus').addEventListener('change', loadAllSkus);
        document.getElementById('filterProduct').addEventListener('change', loadAllSkus);
        let st; document.getElementById('searchSku').addEventListener('input', () => { clearTimeout(st); st = setTimeout(loadAllSkus, 400); });
    }

    async function loadAllSkus() {
        const fd = new FormData();
        fd.append('action', 'list_all_skus');
        fd.append('status', document.getElementById('filterStatus').value);
        fd.append('product_id', document.getElementById('filterProduct').value);
        fd.append('search', document.getElementById('searchSku').value.trim());

        try {
            const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
            const tbody = document.getElementById('skuTableBody');
            const empty = document.getElementById('skuEmpty');
            if (res.success && res.data.length > 0) {
                document.getElementById('skuTable').style.display = '';
                empty.style.display = 'none';
                tbody.innerHTML = res.data.map((s, i) => {
                    let customCells = '';
                    const cd = s.custom_data ? (typeof s.custom_data === 'string' ? JSON.parse(s.custom_data) : s.custom_data) : {};
                    Object.keys(cd).forEach(key => {
                        customCells += `<td data-label="${esc(key)}"><span class="inv-editable" onclick="editSkuCustom(${s.id}, '${esc(key)}', this)" title="Clic para editar">${esc(cd[key]) || '<em style=color:var(--text-muted)>—</em>'}</span></td>`;
                    });
                    const assignedHtml = s.assigned_user_name
                        ? `<span class="assigned-cell"><i class="ph ph-user"></i> ${esc(s.assigned_user_name)}</span>`
                        : '<span style="color:var(--text-muted);font-size:0.82rem;">—</span>';
                    const hist = s.historia || 'ninguno';
                    const lastHistDate = s.last_history_date ? s.last_history_date : '<span style="color:var(--text-muted);">—</span>';
                    const instaladoA = s.acta_cliente ? `<i class="ph ph-user"></i> ${esc(s.acta_cliente)}` : '<span style="color:var(--text-muted);">—</span>';
                    
                    return `<tr>
                        <td data-label="#">${i+1}</td>
                        <td data-label="SKU"><span class="inv-editable" onclick="editSkuCode(${s.id}, this)" title="Clic para editar"><code style="font-weight:700;">${s.sku_code}</code></span></td>
                        <td data-label="Producto">${esc(s.product_name)}</td>
                        <td data-label="Categoría">${esc(s.category_name||'—')}</td>
                        <td data-label="Estado"><span class="status-badge status-${s.status}">${s.status.toUpperCase()}</span></td>
                        <td data-label="Historia"><select class="status-select historia-select" onchange="updateHistoria(${s.id}, this.value)">
                            <option value="ninguno" ${hist==='ninguno'?'selected':''}>—</option>
                            <option value="devuelto" ${hist==='devuelto'?'selected':''}>Devuelto</option>
                            <option value="malogrado" ${hist==='malogrado'?'selected':''}>Malogrado</option>
                            <option value="antiguo" ${hist==='antiguo'?'selected':''}>Antiguo</option>
                            <option value="en_transito" ${hist==='en_transito'?'selected':''}>En Tránsito</option>
                        </select></td>
                        <td data-label="Última Actividad">${lastHistDate}</td>
                        <td data-label="Instalado a">${instaladoA}</td>
                        <td data-label="Asignado">${assignedHtml}</td>
                        <td data-label="Acción"><select class="status-select" onchange="updateSkuStatus(${s.id}, this.value)">
                            <option value="disponible" ${s.status==='disponible'?'selected':''}>Disponible</option>
                            <option value="instalado" ${s.status==='instalado'?'selected':''}>Instalado</option>
                            <option value="malogrado" ${s.status==='malogrado'?'selected':''}>Malogrado</option>
                            <option value="reparado" ${s.status==='reparado'?'selected':''}>Reparado</option>
                            <option value="en_transito" ${s.status==='en_transito'?'selected':''}>En Tránsito</option>
                        </select></td>${customCells}</tr>`;
                }).join('');
                // Update table headers with custom columns
                const thead = document.querySelector('#skuTable thead tr');
                const baseHeaders = '<th>#</th><th>SKU</th><th>Producto</th><th>Categoría</th><th>Estado</th><th>Historia</th><th>Última Actividad</th><th>Instalado a</th><th>Asignado</th><th>Acción</th>';
                let extraHeaders = '';
                if (res.data[0]) {
                    const cd = res.data[0].custom_data ? (typeof res.data[0].custom_data === 'string' ? JSON.parse(res.data[0].custom_data) : res.data[0].custom_data) : {};
                    Object.keys(cd).forEach(key => { extraHeaders += `<th>${esc(key)}</th>`; });
                }
                thead.innerHTML = baseHeaders + extraHeaders;
            } else { document.getElementById('skuTable').style.display = 'none'; empty.style.display = 'block'; }
        } catch (e) { console.error(e); }
        populateProductFilter();
    }

    async function populateProductFilter() {
        const sel = document.getElementById('filterProduct');
        if (sel.options.length > 1) return;
        const fd = new FormData(); fd.append('action', 'list_products');
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) { const cur = sel.value; sel.innerHTML = '<option value="">Todos los productos</option>'; res.data.forEach(p => { sel.innerHTML += `<option value="${p.id}">${esc(p.name)}</option>`; }); sel.value = cur; }
    }

    window.updateSkuStatus = async function(skuId, status) {
        const fd = new FormData(); fd.append('action', 'update_sku_status'); fd.append('sku_id', skuId); fd.append('status', status);
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) { if (window.showToast) window.showToast('Estado actualizado', 'success'); loadAllSkus(); loadMetrics(); loadProducts(); }
    };

    // ── Inline Edit SKU Code ──
    window.editSkuCode = function(skuId, el) {
        const current = el.textContent.trim();
        const input = document.createElement('input');
        input.className = 'inv-editable-input';
        input.value = current;
        el.innerHTML = '';
        el.appendChild(input);
        input.focus(); input.select();
        const save = async () => {
            const val = input.value.trim();
            if (!val || val === current) { el.innerHTML = `<code style="font-weight:700;">${esc(current)}</code>`; return; }
            const fd = new FormData(); fd.append('action', 'update_sku_code'); fd.append('sku_id', skuId); fd.append('sku_code', val);
            const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
            if (res.success) { if (window.showToast) window.showToast('SKU actualizado', 'success'); loadAllSkus(); }
            else { if (window.showToast) window.showToast(res.message, 'error'); el.innerHTML = `<code style="font-weight:700;">${esc(current)}</code>`; }
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); if (e.key === 'Escape') { input.value = current; input.blur(); } });
    };

    // ── Inline Edit SKU Custom Data ──
    window.editSkuCustom = function(skuId, key, el) {
        const current = el.textContent.trim() === '—' ? '' : el.textContent.trim();
        const input = document.createElement('input');
        input.className = 'inv-editable-input';
        input.value = current;
        el.innerHTML = '';
        el.appendChild(input);
        input.focus();
        const save = async () => {
            const val = input.value.trim();
            // Get current row's full custom_data by re-fetching or from DOM
            const row = el.closest('tr');
            const skuCode = row.querySelector('code')?.textContent || '';
            // Fetch current sku data
            const fd1 = new FormData(); fd1.append('action', 'search_sku'); fd1.append('code', skuCode);
            const r1 = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd1 }).then(r => r.json());
            let cd = {};
            if (r1.success && r1.data.custom_data) { cd = typeof r1.data.custom_data === 'string' ? JSON.parse(r1.data.custom_data) : r1.data.custom_data; }
            cd[key] = val;
            const fd = new FormData(); fd.append('action', 'update_sku_custom'); fd.append('sku_id', skuId); fd.append('custom_data', JSON.stringify(cd));
            const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
            if (res.success) { el.innerHTML = val ? esc(val) : '<em style=color:var(--text-muted)>—</em>'; }
            else { el.innerHTML = current ? esc(current) : '<em style=color:var(--text-muted)>—</em>'; }
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); if (e.key === 'Escape') { input.value = current; input.blur(); } });
    };

    // ── Labels Tab ──
    async function populateLabelProducts() {
        const sel = document.getElementById('labelProduct');
        const fd = new FormData(); fd.append('action', 'list_products');
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) { sel.innerHTML = '<option value="">Seleccionar producto...</option>'; res.data.forEach(p => { sel.innerHTML += `<option value="${p.id}">${esc(p.name)} (${p.total_quantity} uds)</option>`; }); }
    }
    function initLabelsTab() { document.getElementById('btnGenLabels').addEventListener('click', generateLabels); }

    async function generateLabels() {
        const productId = document.getElementById('labelProduct').value;
        const labelType = document.getElementById('labelType').value;
        const preview = document.getElementById('labelPreview');
        if (!productId) { if (window.showToast) window.showToast('Selecciona un producto', 'error'); return; }
        const fd = new FormData(); fd.append('action', 'get_product_skus'); fd.append('product_id', productId);
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (!res.success || !res.data.length) { preview.innerHTML = '<div class="empty-state">No hay SKUs.</div>'; return; }

        let html = '<div class="label-sheet">';
        res.data.forEach(s => {
            const id = 'lbl-' + s.id;
            html += labelType === 'barcode'
                ? `<div class="label-item"><svg id="${id}"></svg><div class="label-sku-text">${s.sku_code}</div></div>`
                : `<div class="label-item"><div id="${id}" style="margin:0 auto;"></div><div class="label-sku-text">${s.sku_code}</div></div>`;
        });
        html += '</div>';
        preview.innerHTML = html;

        requestAnimationFrame(() => {
            res.data.forEach(s => {
                const id = 'lbl-' + s.id, el = document.getElementById(id);
                if (!el) return;
                if (labelType === 'barcode') { try { JsBarcode('#'+id, s.sku_code, { format:'CODE128', width:1.2, height:35, displayValue:false, margin:2 }); } catch(e){} }
                else { try { new QRCode(el, { text: s.sku_code, width:60, height:60, colorDark:'#000', colorLight:'#fff', correctLevel: QRCode.CorrectLevel.M }); } catch(e){} }
            });
        });
        document.getElementById('btnPrint').style.display = '';
    }
    // ── SKU Detail Modal ──────────────────────────────────
    let currentSkuData = null;
    let entryPhotoFiles = [];

    function openSkuDetailModal(data) {
        currentSkuData = data;
        document.getElementById('skuDetailTitle').textContent = data.sku_code + ' — ' + data.product_name;
        document.getElementById('skuDetailStatus').value = data.status;

        // Edit tab info
        const info = document.getElementById('skuEditInfo');
        let bulkExtra = data.is_bulk == 1 ? `<div class="sku-info-item"><div class="sii-label">Stock Almacén</div><div class="sii-value" style="font-weight:bold; color:var(--primary-color);">${data.stock} ${data.unit_type||''}</div></div>` : '';
        info.innerHTML = `
            <div class="sku-info-item"><div class="sii-label">SKU Code</div><div class="sii-value"><code>${esc(data.sku_code)}</code></div></div>
            <div class="sku-info-item"><div class="sii-label">Producto</div><div class="sii-value">${esc(data.product_name)}</div></div>
            <div class="sku-info-item"><div class="sii-label">Categoría</div><div class="sii-value">${esc(data.category_name || 'Sin categoría')}</div></div>
            ${data.is_bulk == 1 ? '' : `<div class="sku-info-item"><div class="sii-label">Estado</div><div class="sii-value"><span class="status-badge status-${data.status}">${data.status.toUpperCase()}</span></div></div>`}
            ${data.is_bulk == 1 ? '' : `<div class="sku-info-item"><div class="sii-label">Asignado a</div><div class="sii-value">${data.assigned_user_name ? esc(data.assigned_user_name) : '<span style="color:var(--text-muted)">Sin asignar</span>'}</div></div>`}
            ${bulkExtra}
            <div class="sku-info-item"><div class="sii-label">Descripción</div><div class="sii-value">${esc(data.product_description || '—')}</div></div>`;

        if (data.is_bulk == 1) {
            document.getElementById('skuDetailStatus').parentElement.style.display = 'none';
        } else {
            document.getElementById('skuDetailStatus').parentElement.style.display = 'block';
        }

        // Assign tab
        const assignCurrent = document.getElementById('skuAssignCurrent');
        if (data.is_bulk == 1) {
            assignCurrent.innerHTML = `<div class="assign-badge none"><i class="ph ph-package"></i> Producto a Granel (Stock: ${data.stock} ${data.unit_type||''})</div>`;
        } else if (data.assigned_user_name) {
            assignCurrent.innerHTML = `<div class="assign-badge"><i class="ph ph-user-circle"></i> Asignado a: <strong>${esc(data.assigned_user_name)}</strong></div>`;
        } else {
            assignCurrent.innerHTML = `<div class="assign-badge none"><i class="ph ph-user-circle"></i> Sin asignar</div>`;
        }
        loadUsersForAssign();

        // Entry tab reset
        document.getElementById('entryType').value = 'entrada';
        document.getElementById('entryNotas').value = '';
        document.getElementById('photoPreviewList').innerHTML = '';
        entryPhotoFiles = [];
        loadEntryHistory(data.id);

        // Show modal, default to edit tab
        switchDetailTab('edit');
        document.getElementById('skuDetailModal').classList.add('active');
    }

    window.closeSkuDetail = function() {
        document.getElementById('skuDetailModal').classList.remove('active');
        currentSkuData = null;
    };

    window.switchDetailTab = function(tab) {
        document.querySelectorAll('#skuDetailModal .inv-tab').forEach(t => t.classList.toggle('active', t.dataset.dtab === tab));
        document.querySelectorAll('.sdt-pane').forEach(p => p.classList.remove('active'));
        document.getElementById('dtab-' + tab).classList.add('active');
    };

    // ── Detail: Update Status ──
    window.updateSkuDetailStatus = async function() {
        if (!currentSkuData) return;
        const status = document.getElementById('skuDetailStatus').value;
        const fd = new FormData(); fd.append('action', 'update_sku_status'); fd.append('sku_id', currentSkuData.id); fd.append('status', status);
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) {
            currentSkuData.status = status;
            if (window.showToast) window.showToast('Estado actualizado', 'success');
            loadAllSkus(); loadMetrics(); loadProducts();
            // Update info display
            const badge = document.querySelector('#skuEditInfo .status-badge');
            if (badge) { badge.className = 'status-badge status-' + status; badge.textContent = status.toUpperCase(); }
        }
    };

    // ── Detail: Load users for assign ──
    async function loadUsersForAssign() {
        const fd = new FormData(); fd.append('action', 'list_users');
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) {
            const sel = document.getElementById('skuAssignUser');
            sel.innerHTML = '<option value="">Seleccionar usuario...</option>';
            res.data.forEach(u => {
                const selected = currentSkuData && currentSkuData.assigned_to == u.id ? 'selected' : '';
                sel.innerHTML += `<option value="${u.id}" ${selected}>${esc(u.name)} (${esc(u.email)})</option>`;
            });
        }
    }

    window.assignSkuToUser = async function() {
        if (!currentSkuData) return;
        const userId = document.getElementById('skuAssignUser').value;
        if (!userId) { if (window.showToast) window.showToast('Selecciona un usuario', 'error'); return; }
        
        let quantity = 0;
        if (currentSkuData.is_bulk == 1) {
            const qtyStr = prompt(`Ingresa la cantidad a asignar (Disponible: ${currentSkuData.stock} ${currentSkuData.unit_type||''}):`);
            if (!qtyStr) return;
            quantity = parseFloat(qtyStr);
            if (isNaN(quantity) || quantity <= 0) {
                if (window.showToast) window.showToast('Cantidad inválida', 'error');
                return;
            }
        }

        const fd = new FormData(); fd.append('action', 'assign_sku'); fd.append('sku_id', currentSkuData.id); fd.append('user_id', userId);
        if (currentSkuData.is_bulk == 1) fd.append('quantity', quantity);

        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) {
            if (window.showToast) window.showToast(res.message, 'success');
            if (currentSkuData.is_bulk != 1) {
                currentSkuData.assigned_to = userId;
                currentSkuData.assigned_user_name = res.user_name;
                document.getElementById('skuAssignCurrent').innerHTML = `<div class="assign-badge"><i class="ph ph-user-circle"></i> Asignado a: <strong>${esc(res.user_name)}</strong></div>`;
                loadAllSkus();
            } else {
                closeSkuDetail();
                loadProducts(); // Refresh warehouse stock
            }
        } else {
            if (window.showToast) window.showToast(res.message, 'error');
        }
    };

    window.unassignSku = async function() {
        if (!currentSkuData) return;
        const fd = new FormData(); fd.append('action', 'unassign_sku'); fd.append('sku_id', currentSkuData.id);
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) {
            if (window.showToast) window.showToast('Asignación removida', 'success');
            currentSkuData.assigned_to = null;
            currentSkuData.assigned_user_name = null;
            document.getElementById('skuAssignCurrent').innerHTML = `<div class="assign-badge none"><i class="ph ph-user-circle"></i> Sin asignar</div>`;
            loadAllSkus();
        }
    };

    // ── Detail: Photo upload preview ──
    window.previewEntryPhotos = function(input) {
        const list = document.getElementById('photoPreviewList');
        const files = Array.from(input.files);
        files.forEach((file, idx) => {
            entryPhotoFiles.push(file);
            const reader = new FileReader();
            reader.onload = (e) => {
                const fileIdx = entryPhotoFiles.length - files.length + idx;
                const thumb = document.createElement('div');
                thumb.className = 'inv-photo-thumb';
                thumb.innerHTML = `<img src="${e.target.result}"><button class="remove-photo" onclick="removeEntryPhoto(${fileIdx},this.parentElement)">&times;</button>`;
                list.appendChild(thumb);
            };
            reader.readAsDataURL(file);
        });
    };

    window.removeEntryPhoto = function(idx, el) {
        entryPhotoFiles.splice(idx, 1);
        el.remove();
    };

    // ── Detail: Submit Entry ──
    window.submitEntry = async function() {
        if (!currentSkuData) return;
        const tipo = document.getElementById('entryType').value;
        const notas = document.getElementById('entryNotas').value.trim();

        const fd = new FormData();
        fd.append('action', 'create_entry');
        fd.append('sku_id', currentSkuData.id);
        fd.append('tipo', tipo);
        fd.append('notas', notas);
        entryPhotoFiles.forEach(f => fd.append('photos[]', f));

        try {
            const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
            if (res.success) {
                if (window.showToast) window.showToast('Movimiento registrado', 'success');
                document.getElementById('entryNotas').value = '';
                document.getElementById('photoPreviewList').innerHTML = '';
                entryPhotoFiles = [];
                loadEntryHistory(currentSkuData.id);
                loadAllSkus(); loadMetrics(); loadProducts();
            } else {
                if (window.showToast) window.showToast(res.message, 'error');
            }
        } catch (e) { if (window.showToast) window.showToast('Error del servidor', 'error'); }
    };

    // ── Update Historia from table ──
    window.updateHistoria = async function(skuId, historia) {
        const fd = new FormData();
        fd.append('action', 'update_historia');
        fd.append('sku_id', skuId);
        fd.append('historia', historia);
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        if (res.success) {
            if (window.showToast) window.showToast('Historia actualizada', 'success');
        }
    };

    // ── Detail: Load Entry History ──
    async function loadEntryHistory(skuId) {
        const fd = new FormData(); fd.append('action', 'get_sku_entries'); fd.append('sku_id', skuId);
        const res = await fetch(BASE + '/ajax/inventario.php', { method: 'POST', body: fd }).then(r => r.json());
        const list = document.getElementById('entryHistoryList');
        if (res.success && res.data.length > 0) {
            const tipoLabel = { entrada: '📥 Entrada', salida: '📤 Salida', devolucion: '🔄 Devolución', reparacion: '🔧 Reparación' };
            list.innerHTML = res.data.map(e => {
                let photosHtml = '';
                if (e.photos) {
                    const arr = e.photos.split(',');
                    photosHtml = `<div class="inv-entry-photos">${arr.map(p => `<img src="${BASE}/${p}" onclick="window.open('${BASE}/${p}','_blank')">`).join('')}</div>`;
                }
                return `<div class="inv-entry-item">
                    <div class="entry-header"><span class="entry-type">${tipoLabel[e.tipo] || e.tipo}</span><span class="entry-date">${e.created_at}</span></div>
                    <div class="entry-user"><i class="ph ph-user"></i> ${esc(e.user_name)}</div>
                    ${e.notas ? `<div class="entry-notes">${esc(e.notas)}</div>` : ''}
                    ${photosHtml}
                </div>`;
            }).join('');
        } else {
            list.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:16px;font-size:0.85rem;">Sin registros aún.</p>';
        }
    }

    // ── Helpers ──
    function esc(s) { if (!s) return ''; const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
    function randomCode(n) { const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let r = ''; for (let i=0;i<n;i++) r+=c[Math.floor(Math.random()*c.length)]; return r; }
})();
