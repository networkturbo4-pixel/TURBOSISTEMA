<?php
$session_path = __DIR__ . '/../sessions';
if (!is_dir($session_path)) {
    @mkdir($session_path, 0777, true);
}
session_save_path($session_path);
session_start();

$host = 'localhost';
$dbname = 'turbosaas_db';
$user = 'root';
$pass = '';

define('BASE_URL', '/TURBOSAAS');
require_once __DIR__ . '/env.php';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Helper para verificar si está logueado
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: " . BASE_URL . "/login.php");
        exit;
    }
}

require_once __DIR__ . '/modules.php';
?>
